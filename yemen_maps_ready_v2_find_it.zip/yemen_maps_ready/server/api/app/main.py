import json
import os
import uuid
from typing import Literal, Optional

import psycopg
from psycopg.rows import dict_row
from fastapi import Depends, FastAPI, Header, HTTPException, Query, Response
from pydantic import BaseModel, Field

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://yemenmaps:change_me@postgis:5432/yemenmaps",
)

app = FastAPI(title="Yemen Maps API", version="0.2.0")


def db():
    return psycopg.connect(DATABASE_URL, row_factory=dict_row)


def dev_user_id(x_user_id: Optional[str] = Header(default=None, alias="X-User-Id")) -> uuid.UUID:
    """Development identity only. Replace with JWT verification before production."""
    if not x_user_id:
        raise HTTPException(status_code=401, detail="X-User-Id required in development mode")
    try:
        return uuid.UUID(x_user_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid X-User-Id") from exc


class MerchantStoreInput(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    phone: str = Field(min_length=5, max_length=40)
    whatsapp: str = Field(min_length=5, max_length=40)
    governorate: str = Field(default="صنعاء", min_length=2, max_length=80)
    district: str = Field(min_length=1, max_length=120)
    address: str = Field(min_length=2, max_length=300)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    openingHours: str = Field(default="")


class MerchantListingInput(BaseModel):
    merchantId: uuid.UUID
    type: Literal["product", "service"]
    name: str = Field(min_length=2, max_length=180)
    category: str = Field(min_length=1, max_length=120)
    description: Optional[str] = Field(default=None, max_length=1000)
    searchAliases: list[str] = Field(default_factory=list)
    price: Optional[float] = Field(default=None, ge=0)
    currency: str = Field(default="YER", min_length=3, max_length=3)
    availability: Literal["available", "unavailable", "on_request"] = "available"


@app.get("/health")
def health():
    with db() as conn:
        conn.execute("SELECT 1")
    return {"ok": True, "service": "yemen-maps-api"}


@app.get("/v1/search")
def search_places(
    q: str = "",
    category: Optional[str] = None,
    lat: float = 15.3694,
    lon: float = 44.1910,
    limit: int = Query(default=30, ge=1, le=100),
):
    clauses = ["p.is_active = TRUE"]
    params: dict = {"lat": lat, "lon": lon, "limit": limit}
    if q.strip():
        clauses.append("(p.name ILIKE %(q_like)s OR p.name %% %(q)s OR %(q)s = ANY(p.old_names))")
        params["q"] = q.strip()
        params["q_like"] = f"%{q.strip()}%"
    if category:
        clauses.append("p.category = %(category)s")
        params["category"] = category
    sql = f"""
        SELECT p.id::text AS id, p.name, p.category, p.address,
               ST_Y(p.geom::geometry) AS latitude,
               ST_X(p.geom::geometry) AS longitude,
               ST_Distance(p.geom, ST_SetSRID(ST_MakePoint(%(lon)s,%(lat)s),4326)::geography) AS "distanceMeters"
        FROM places p
        WHERE {' AND '.join(clauses)}
        ORDER BY "distanceMeters" ASC
        LIMIT %(limit)s
    """
    with db() as conn:
        return conn.execute(sql, params).fetchall()


@app.get("/v1/nearby")
def nearby_places(
    category: str,
    lat: float,
    lon: float,
    limit: int = Query(default=30, ge=1, le=100),
):
    sql = """
        SELECT p.id::text AS id, p.name, p.category, p.address,
               ST_Y(p.geom::geometry) AS latitude,
               ST_X(p.geom::geometry) AS longitude,
               ST_Distance(p.geom, ST_SetSRID(ST_MakePoint(%(lon)s,%(lat)s),4326)::geography) AS "distanceMeters"
        FROM places p
        WHERE p.is_active = TRUE AND p.category = %(category)s
        ORDER BY "distanceMeters" ASC
        LIMIT %(limit)s
    """
    with db() as conn:
        return conn.execute(sql, {"category": category, "lat": lat, "lon": lon, "limit": limit}).fetchall()


@app.get("/v1/market/search")
def market_search(
    q: str = Query(min_length=1),
    lat: float = 15.3694,
    lon: float = 44.1910,
    governorate: str = "صنعاء",
    district: Optional[str] = None,
    itemType: Optional[Literal["product", "service"]] = None,
    minPrice: Optional[float] = Query(default=None, ge=0),
    maxPrice: Optional[float] = Query(default=None, ge=0),
    maxDistanceKm: float = Query(default=25, gt=0, le=500),
    availability: Optional[Literal["available", "unavailable", "on_request"]] = None,
    sort: Literal["nearest", "cheapest", "latest", "available"] = "nearest",
    limit: int = Query(default=50, ge=1, le=100),
):
    clauses = [
        "i.is_active = TRUE",
        "m.is_active = TRUE",
        "p.is_active = TRUE",
        "COALESCE(p.governorate, '') = %(governorate)s",
        "ST_DWithin(p.geom, ST_SetSRID(ST_MakePoint(%(lon)s,%(lat)s),4326)::geography, %(max_distance_m)s)",
        "(i.name ILIKE %(q_like)s OR i.name %% %(q)s OR i.category ILIKE %(q_like)s OR EXISTS (SELECT 1 FROM unnest(i.search_aliases) a WHERE a ILIKE %(q_like)s))",
    ]
    params: dict = {
        "q": q.strip(),
        "q_like": f"%{q.strip()}%",
        "lat": lat,
        "lon": lon,
        "governorate": governorate,
        "max_distance_m": maxDistanceKm * 1000,
        "limit": limit,
    }
    if district:
        clauses.append("COALESCE(p.district, '') ILIKE %(district)s")
        params["district"] = f"%{district.strip()}%"
    if itemType:
        clauses.append("i.item_type = %(item_type)s")
        params["item_type"] = itemType
    if minPrice is not None:
        clauses.append("i.price IS NOT NULL AND i.price >= %(min_price)s")
        params["min_price"] = minPrice
    if maxPrice is not None:
        clauses.append("i.price IS NOT NULL AND i.price <= %(max_price)s")
        params["max_price"] = maxPrice
    if availability:
        clauses.append("i.availability = %(availability)s")
        params["availability"] = availability

    order_by = {
        "nearest": '"distanceMeters" ASC',
        "cheapest": 'i.price ASC NULLS LAST, "distanceMeters" ASC',
        "latest": 'i.updated_at DESC, "distanceMeters" ASC',
        "available": "CASE WHEN i.availability='available' THEN 0 ELSE 1 END, \"distanceMeters\" ASC",
    }[sort]

    sql = f"""
        SELECT
          i.id::text AS id,
          m.id::text AS "merchantId",
          m.display_name AS "merchantName",
          i.name AS "itemName",
          i.item_type AS type,
          i.category,
          i.description,
          i.price::float8 AS price,
          trim(i.currency) AS currency,
          i.availability,
          COALESCE(p.governorate, '') AS governorate,
          COALESCE(p.district, '') AS district,
          p.address,
          ST_Y(p.geom::geometry) AS latitude,
          ST_X(p.geom::geometry) AS longitude,
          ST_Distance(p.geom, ST_SetSRID(ST_MakePoint(%(lon)s,%(lat)s),4326)::geography) AS "distanceMeters",
          COALESCE(NULLIF(m.phone,''), p.phone, '') AS phone,
          COALESCE(NULLIF(m.whatsapp,''), p.whatsapp, '') AS whatsapp,
          COALESCE(p.opening_hours->>'display', '') AS "openingHours",
          i.updated_at AS "updatedAt"
        FROM merchant_catalog_items i
        JOIN merchant_profiles m ON m.id = i.merchant_id
        JOIN places p ON p.id = m.place_id
        WHERE {' AND '.join(clauses)}
        ORDER BY {order_by}
        LIMIT %(limit)s
    """
    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {"items": rows}


@app.get("/v1/market/listings/{listing_id}")
def market_listing(listing_id: uuid.UUID, lat: float = 15.3694, lon: float = 44.1910):
    sql = """
        SELECT
          i.id::text AS id, m.id::text AS "merchantId", m.display_name AS "merchantName",
          i.name AS "itemName", i.item_type AS type, i.category, i.description,
          i.price::float8 AS price, trim(i.currency) AS currency, i.availability,
          COALESCE(p.governorate, '') AS governorate, COALESCE(p.district, '') AS district,
          p.address, ST_Y(p.geom::geometry) AS latitude, ST_X(p.geom::geometry) AS longitude,
          ST_Distance(p.geom, ST_SetSRID(ST_MakePoint(%(lon)s,%(lat)s),4326)::geography) AS "distanceMeters",
          COALESCE(NULLIF(m.phone,''), p.phone, '') AS phone,
          COALESCE(NULLIF(m.whatsapp,''), p.whatsapp, '') AS whatsapp,
          COALESCE(p.opening_hours->>'display', '') AS "openingHours", i.updated_at AS "updatedAt"
        FROM merchant_catalog_items i
        JOIN merchant_profiles m ON m.id = i.merchant_id
        JOIN places p ON p.id = m.place_id
        WHERE i.id = %(id)s AND i.is_active = TRUE AND m.is_active = TRUE AND p.is_active = TRUE
    """
    with db() as conn:
        row = conn.execute(sql, {"id": listing_id, "lat": lat, "lon": lon}).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Listing not found")
    return row


@app.post("/v1/merchant/stores", status_code=201)
def create_store(payload: MerchantStoreInput, user_id: uuid.UUID = Depends(dev_user_id)):
    with db() as conn:
        with conn.transaction():
            place = conn.execute(
                """
                INSERT INTO places(name, category, address, phone, whatsapp, geom, verification_status,
                                   owner_user_id, governorate, district, opening_hours)
                VALUES (%(name)s, 'other', %(address)s, %(phone)s, %(whatsapp)s,
                        ST_SetSRID(ST_MakePoint(%(lon)s,%(lat)s),4326)::geography,
                        'unverified', %(user_id)s, %(governorate)s, %(district)s, %(opening_hours)s::jsonb)
                RETURNING id
                """,
                {
                    "name": payload.name,
                    "address": payload.address,
                    "phone": payload.phone,
                    "whatsapp": payload.whatsapp,
                    "lon": payload.longitude,
                    "lat": payload.latitude,
                    "user_id": user_id,
                    "governorate": payload.governorate,
                    "district": payload.district,
                    "opening_hours": json.dumps({"display": payload.openingHours}, ensure_ascii=False),
                },
            ).fetchone()
            merchant = conn.execute(
                """
                INSERT INTO merchant_profiles(user_id, place_id, display_name, phone, whatsapp)
                VALUES (%(user_id)s, %(place_id)s, %(name)s, %(phone)s, %(whatsapp)s)
                RETURNING id
                """,
                {
                    "user_id": user_id,
                    "place_id": place["id"],
                    "name": payload.name,
                    "phone": payload.phone,
                    "whatsapp": payload.whatsapp,
                },
            ).fetchone()
    return {"id": str(merchant["id"]), "placeId": str(place["id"]), "status": "created"}


@app.patch("/v1/merchant/stores/{merchant_id}")
def update_store(merchant_id: uuid.UUID, payload: MerchantStoreInput, user_id: uuid.UUID = Depends(dev_user_id)):
    with db() as conn:
        with conn.transaction():
            owned = conn.execute(
                "SELECT place_id FROM merchant_profiles WHERE id=%s AND user_id=%s",
                (merchant_id, user_id),
            ).fetchone()
            if not owned:
                raise HTTPException(status_code=404, detail="Merchant not found")
            conn.execute(
                """
                UPDATE places
                   SET name=%(name)s, address=%(address)s, phone=%(phone)s, whatsapp=%(whatsapp)s,
                       governorate=%(governorate)s, district=%(district)s,
                       geom=ST_SetSRID(ST_MakePoint(%(lon)s,%(lat)s),4326)::geography,
                       opening_hours=%(opening_hours)s::jsonb, updated_at=now()
                 WHERE id=%(place_id)s
                """,
                {
                    "name": payload.name,
                    "address": payload.address,
                    "phone": payload.phone,
                    "whatsapp": payload.whatsapp,
                    "governorate": payload.governorate,
                    "district": payload.district,
                    "lon": payload.longitude,
                    "lat": payload.latitude,
                    "opening_hours": json.dumps({"display": payload.openingHours}, ensure_ascii=False),
                    "place_id": owned["place_id"],
                },
            )
            conn.execute(
                "UPDATE merchant_profiles SET display_name=%s, phone=%s, whatsapp=%s, updated_at=now() WHERE id=%s",
                (payload.name, payload.phone, payload.whatsapp, merchant_id),
            )
    return {"id": str(merchant_id), "status": "updated"}


@app.post("/v1/merchant/listings", status_code=201)
def create_listing(payload: MerchantListingInput, user_id: uuid.UUID = Depends(dev_user_id)):
    with db() as conn:
        owned = conn.execute(
            "SELECT 1 FROM merchant_profiles WHERE id=%s AND user_id=%s AND is_active=TRUE",
            (payload.merchantId, user_id),
        ).fetchone()
        if not owned:
            raise HTTPException(status_code=404, detail="Merchant not found")
        row = conn.execute(
            """
            INSERT INTO merchant_catalog_items(
              merchant_id, item_type, name, category, description, search_aliases,
              price, currency, availability, price_updated_at, availability_updated_at
            ) VALUES (
              %(merchant_id)s, %(item_type)s, %(name)s, %(category)s, %(description)s, %(aliases)s,
              %(price)s, %(currency)s, %(availability)s,
              CASE WHEN %(price)s IS NULL THEN NULL ELSE now() END, now()
            ) RETURNING id
            """,
            {
                "merchant_id": payload.merchantId,
                "item_type": payload.type,
                "name": payload.name,
                "category": payload.category,
                "description": payload.description,
                "aliases": payload.searchAliases,
                "price": payload.price,
                "currency": payload.currency.upper(),
                "availability": payload.availability,
            },
        ).fetchone()
        conn.commit()
    return {"id": str(row["id"]), "status": "created"}


@app.patch("/v1/merchant/listings/{listing_id}")
def update_listing(listing_id: uuid.UUID, payload: MerchantListingInput, user_id: uuid.UUID = Depends(dev_user_id)):
    with db() as conn:
        owned = conn.execute(
            """
            SELECT i.price, i.availability
            FROM merchant_catalog_items i
            JOIN merchant_profiles m ON m.id=i.merchant_id
            WHERE i.id=%s AND m.user_id=%s AND m.id=%s
            """,
            (listing_id, user_id, payload.merchantId),
        ).fetchone()
        if not owned:
            raise HTTPException(status_code=404, detail="Listing not found")
        conn.execute(
            """
            UPDATE merchant_catalog_items
               SET item_type=%(item_type)s, name=%(name)s, category=%(category)s,
                   description=%(description)s, search_aliases=%(aliases)s,
                   price=%(price)s, currency=%(currency)s, availability=%(availability)s,
                   price_updated_at=CASE WHEN price IS DISTINCT FROM %(price)s THEN now() ELSE price_updated_at END,
                   availability_updated_at=CASE WHEN availability IS DISTINCT FROM %(availability)s THEN now() ELSE availability_updated_at END,
                   updated_at=now()
             WHERE id=%(id)s
            """,
            {
                "id": listing_id,
                "item_type": payload.type,
                "name": payload.name,
                "category": payload.category,
                "description": payload.description,
                "aliases": payload.searchAliases,
                "price": payload.price,
                "currency": payload.currency.upper(),
                "availability": payload.availability,
            },
        )
        conn.commit()
    return {"id": str(listing_id), "status": "updated"}


@app.delete("/v1/merchant/listings/{listing_id}", status_code=204)
def delete_listing(listing_id: uuid.UUID, user_id: uuid.UUID = Depends(dev_user_id)):
    with db() as conn:
        result = conn.execute(
            """
            UPDATE merchant_catalog_items i
               SET is_active=FALSE, updated_at=now()
              FROM merchant_profiles m
             WHERE i.id=%s AND i.merchant_id=m.id AND m.user_id=%s
            RETURNING i.id
            """,
            (listing_id, user_id),
        ).fetchone()
        conn.commit()
    if not result:
        raise HTTPException(status_code=404, detail="Listing not found")
    return Response(status_code=204)
