#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PUBLIC_BASE_URL="${1:-http://localhost:8088}"
SOURCE_ID="${2:-yemen-shortbread-1.0}"
TEMPLATE="$BASE_DIR/../assets/map/yemen_light_style.template.json"
OUT="$BASE_DIR/styles/yemen-light.json"
mkdir -p "$BASE_DIR/styles"
cp "$TEMPLATE" "$OUT"
sed -i "s#__TILE_URL__#$PUBLIC_BASE_URL/tiles/$SOURCE_ID#g" "$OUT"
# Martin can serve glyphs/styles if configured; during first deployment point these to your chosen glyph service.
sed -i "s#__GLYPHS_URL__#$PUBLIC_BASE_URL/fonts#g" "$OUT"
sed -i "s#__SPRITE_URL__#$PUBLIC_BASE_URL/sprites/basic#g" "$OUT"
echo "Wrote $OUT"
echo "If fonts/sprites are not hosted yet, remove the symbol layers temporarily or configure Martin supporting resources."
