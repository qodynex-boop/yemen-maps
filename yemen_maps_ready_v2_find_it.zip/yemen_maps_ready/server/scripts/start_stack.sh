#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ ! -f ./valhalla/custom_files/yemen-latest.osm.pbf || ! -f ./tiles/yemen-shortbread-1.0.mbtiles ]]; then
  ./scripts/download_yemen_data.sh
fi
docker compose up -d
printf '\nServices:\n  Routing: http://SERVER:8002/route\n  Tiles:   http://SERVER:3000/\n  Gateway: http://SERVER:8088/\n'
