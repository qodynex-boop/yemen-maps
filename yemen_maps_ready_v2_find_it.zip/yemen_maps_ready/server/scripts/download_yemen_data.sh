#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$BASE_DIR/valhalla/custom_files" "$BASE_DIR/tiles"

echo "Downloading Yemen OSM PBF for routing..."
curl -fL --retry 4 -o "$BASE_DIR/valhalla/custom_files/yemen-latest.osm.pbf" \
  https://download.geofabrik.de/asia/yemen-latest.osm.pbf

echo "Downloading Geofabrik Shortbread vector tiles for Yemen..."
curl -fL --retry 4 -o "$BASE_DIR/tiles/yemen-shortbread-1.0.mbtiles" \
  https://download.geofabrik.de/asia/yemen-shortbread-1.0.mbtiles

echo "Done."
ls -lh "$BASE_DIR/valhalla/custom_files/yemen-latest.osm.pbf" "$BASE_DIR/tiles/yemen-shortbread-1.0.mbtiles"
