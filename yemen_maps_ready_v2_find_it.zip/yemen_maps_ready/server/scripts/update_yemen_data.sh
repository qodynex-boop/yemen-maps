#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$BASE_DIR"
./scripts/download_yemen_data.sh
# Valhalla sees the changed local PBF after restart and rebuilds when needed.
docker compose restart valhalla martin

echo "Yemen OSM/tiles refreshed. Check Valhalla logs while routing graph rebuilds:"
echo "  docker compose logs -f valhalla"
