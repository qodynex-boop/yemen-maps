# حزمة السيرفر

- `docker-compose.yml`: FastAPI + PostGIS + Valhalla + Martin + Nginx.
- `scripts/download_yemen_data.sh`: تنزيل أحدث OSM PBF وخريطة Shortbread MBTiles لليمن من Geofabrik.
- `scripts/update_yemen_data.sh`: تحديث البيانات وإعادة تشغيل الخدمات.
- `scripts/prepare_style.sh`: تجهيز style MapLibre بعنوان السيرفر.
- `db/schema.sql`: قاعدة الأنشطة وطلبات الملكية وتغيير البيانات.
- `openapi/openapi.yaml`: العقد الذي يتوقعه تطبيق Flutter لخدمة البحث.

## تشغيل سريع

```bash
./scripts/download_yemen_data.sh
./scripts/prepare_style.sh https://maps.example.com
docker compose up -d
```

بعد ذلك ضع روابط الإنتاج في `../assets/config/app_config.json`.


## «وين ألاقيه؟»

- API: `api/app/main.py`
- Migration: `db/migrations/002_find_it.sql`
- OpenAPI: `openapi/openapi.yaml`
- المنفذ المحلي للـAPI: `8080`
- عبر Nginx: `/api/`

إذا كانت قاعدة PostGIS موجودة من نسخة سابقة، نفّذ migration يدويًا مرة واحدة:

```bash
psql "$DATABASE_URL" -f db/migrations/002_find_it.sql
```

لا تعتمد `X-User-Id` في الإنتاج؛ هو مجرد هوية تطوير مؤقتة حتى إضافة JWT.

### بيانات اختبار اختيارية

`db/demo_find_it_seed.sql` يضيف سجلات خيالية لاختبار البحث عبر الـAPI. لا يتم تشغيله تلقائيًا.
