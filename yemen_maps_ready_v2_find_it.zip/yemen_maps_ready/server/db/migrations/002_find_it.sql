-- «وين ألاقيه؟» — إضافة سوق المنتجات والخدمات بدون تغيير نظام الخرائط/الملاحة.

ALTER TABLE places ADD COLUMN IF NOT EXISTS country_code TEXT NOT NULL DEFAULT 'YE';
ALTER TABLE places ADD COLUMN IF NOT EXISTS governorate TEXT;
ALTER TABLE places ADD COLUMN IF NOT EXISTS district TEXT;
ALTER TABLE places ADD COLUMN IF NOT EXISTS locality TEXT;
ALTER TABLE places ADD COLUMN IF NOT EXISTS opening_hours JSONB NOT NULL DEFAULT '{}'::jsonb;

CREATE INDEX IF NOT EXISTS places_governorate_idx ON places(governorate);
CREATE INDEX IF NOT EXISTS places_district_idx ON places(district);

CREATE TABLE IF NOT EXISTS merchant_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  place_id UUID NOT NULL UNIQUE REFERENCES places(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  whatsapp TEXT NOT NULL,
  verification_status TEXT NOT NULL DEFAULT 'unverified'
    CHECK (verification_status IN ('unverified', 'pending', 'verified', 'rejected')),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS merchant_profiles_user_idx ON merchant_profiles(user_id);
CREATE INDEX IF NOT EXISTS merchant_profiles_active_idx ON merchant_profiles(is_active);

CREATE TABLE IF NOT EXISTS merchant_catalog_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  merchant_id UUID NOT NULL REFERENCES merchant_profiles(id) ON DELETE CASCADE,
  item_type TEXT NOT NULL CHECK (item_type IN ('product', 'service')),
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT,
  search_aliases TEXT[] NOT NULL DEFAULT '{}',
  price NUMERIC(18,2),
  currency CHAR(3) NOT NULL DEFAULT 'YER',
  availability TEXT NOT NULL DEFAULT 'available'
    CHECK (availability IN ('available', 'unavailable', 'on_request')),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  price_updated_at TIMESTAMPTZ,
  availability_updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS merchant_catalog_name_trgm ON merchant_catalog_items USING GIN (name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS merchant_catalog_category_trgm ON merchant_catalog_items USING GIN (category gin_trgm_ops);
CREATE INDEX IF NOT EXISTS merchant_catalog_aliases_gin ON merchant_catalog_items USING GIN (search_aliases);
CREATE INDEX IF NOT EXISTS merchant_catalog_price_idx ON merchant_catalog_items(price) WHERE price IS NOT NULL;
CREATE INDEX IF NOT EXISTS merchant_catalog_availability_idx ON merchant_catalog_items(availability, is_active);
CREATE INDEX IF NOT EXISTS merchant_catalog_updated_idx ON merchant_catalog_items(updated_at DESC);
CREATE INDEX IF NOT EXISTS merchant_catalog_merchant_idx ON merchant_catalog_items(merchant_id);

CREATE TABLE IF NOT EXISTS merchant_catalog_change_log (
  id BIGSERIAL PRIMARY KEY,
  catalog_item_id UUID NOT NULL REFERENCES merchant_catalog_items(id) ON DELETE CASCADE,
  changed_by_user_id UUID,
  change_type TEXT NOT NULL,
  old_value JSONB,
  new_value JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS merchant_catalog_change_log_item_idx
  ON merchant_catalog_change_log(catalog_item_id, created_at DESC);

-- مثال بحث جغرافي للسيرفر:
-- SELECT i.*, m.display_name, p.phone, p.whatsapp,
--        ST_Distance(p.geom, ST_SetSRID(ST_MakePoint(:lon, :lat),4326)::geography) AS distance_m
-- FROM merchant_catalog_items i
-- JOIN merchant_profiles m ON m.id = i.merchant_id
-- JOIN places p ON p.id = m.place_id
-- WHERE i.is_active AND m.is_active AND p.is_active
--   AND (i.name % :q OR i.name ILIKE '%' || :q || '%' OR i.category ILIKE '%' || :q || '%')
--   AND ST_DWithin(p.geom, ST_SetSRID(ST_MakePoint(:lon, :lat),4326)::geography, :max_distance_m)
-- ORDER BY distance_m ASC;
