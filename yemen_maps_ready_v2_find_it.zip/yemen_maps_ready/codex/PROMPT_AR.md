# برومبت التسليم إلى Codex

أنت تستلم مشروع Flutter جاهز لواجهة "خرائط اليمن". لا تعيد تصميم الواجهة ولا تغيّر الهوية أو ترتيب الأقسام. اعتبر الصورة `assets/reference/home_reference.png` مرجعًا بصريًا إلزاميًا.

## المطلوب منك فقط
1. شغّل/أكمل Scaffold Flutter Android إن كانت ملفات المنصة غير موجودة عبر `flutter create --platforms=android .` بدون حذف `lib/` أو `assets/` أو `server/`.
2. تأكد أن المشروع يبني على Flutter حديث متوافق مع `maplibre_gl 0.27.1`.
3. أضف Android permissions للموقع والإنترنت فقط كما يلزم.
4. اربط إعدادات الإنتاج في `assets/config/app_config.json` مع خادمنا:
   - `apiBaseUrl`
   - `routingBaseUrl`
   - `mapStyleUrl`
5. لا تغيّر API contracts الموجودة في `server/openapi/openapi.yaml` إلا إذا كان هناك سبب تقني، وفي هذه الحالة حدّث العميل والعقد معًا.
6. اختبر السيناريو كاملًا:
   - فتح الرئيسية.
   - اختيار سيارة/مشي/دراجة/باص.
   - البحث عن مكان.
   - اختيار نتيجة.
   - حساب المسار من GPS.
   - رسم المسار.
   - بدء الإرشادات الصوتية العربية.
7. أصلح أي خطأ compile/runtime يظهر، لكن لا تعيد بناء التصميم من الصفر.
8. وفّر build APK release في النهاية.

## ممنوع
- استبدال MapLibre بـ Google Maps.
- إضافة API key لخرائط تجارية بدون طلب.
- حذف Arabic TTS المحلي.
- إزالة الإسناد لـ OpenStreetMap.
- تغيير أسماء الأقسام السبعة الأساسية.

## قبول المهمة
راجع `codex/ACCEPTANCE_CRITERIA_AR.md`.

## إضافة موجودة بالفعل: «وين ألاقيه؟»

لا تعِد بناء الميزة من الصفر. راجع فقط وربطها بالإنتاج:

- `lib/features/find_it/` يحتوي البحث والنتائج والفلاتر وربط زر «اذهب» بـ `NavigationScreen` الحالي.
- `server/api/` يحتوي FastAPI المبدئي.
- `server/db/migrations/002_find_it.sql` يحتوي الجداول والفهارس.
- `assets/find_it/demo_listings.json` بيانات اختبار خيالية فقط؛ بعد نجاح API لا تظهر للمستخدم إلا عند انقطاع السيرفر.
- استبدل هوية التطوير `X-User-Id` بمصادقة JWT حقيقية قبل الإنتاج.
- لا تغيّر بنية Valhalla أو MapLibre أو TTS بسبب هذه الميزة.
