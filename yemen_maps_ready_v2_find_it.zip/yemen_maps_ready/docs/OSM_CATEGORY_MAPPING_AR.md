# تحويل تصنيفات OpenStreetMap إلى أقسام التطبيق

هذه الخريطة تستخدم عند بناء مستورد POI من `yemen-latest.osm.pbf` إلى جدول `places`.

| قسم التطبيق | أهم وسوم OSM المقترحة |
|---|---|
| مطاعم وكافيهات `food` | `amenity=restaurant`, `cafe`, `fast_food`, `food_court` |
| محطات الوقود `fuel` | `amenity=fuel`, ويمكن إضافة `charging_station` لاحقًا |
| المدارس `school` | `amenity=school`, `kindergarten`, `college`, `university` |
| المراكز الصحية `health` | `amenity=hospital`, `clinic`, `doctors`, `pharmacy`, `dentist` |
| المرافق الحكومية `government` | `office=government`, `amenity=townhall`, `courthouse`, `police`, `fire_station`, `post_office` |
| الحدائق `parks` | `leisure=park`, `garden`, `playground` |

## قاعدة مهمة
لا تجعل OSM هو المصدر الوحيد. خزّن `source` و`source_id` لكل مكان، ثم اسمح ببيانات المجتمع وأصحاب الأنشطة مع سجل تغييرات مستقل.
