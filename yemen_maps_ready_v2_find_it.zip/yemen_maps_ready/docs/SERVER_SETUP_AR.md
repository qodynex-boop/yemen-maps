# تشغيل خدمات خرائط اليمن على VPS

المجلد `server/` مجهز لثلاث خدمات رئيسية:

1. **Valhalla** للمسارات والملاحة.
2. **Martin** لتقديم Vector Tiles من ملف Yemen Shortbread MBTiles.
3. **PostGIS** لبيانات الأنشطة الخاصة بالمشروع.

## أوامر الخادم

```bash
cd server
./scripts/download_yemen_data.sh
./scripts/prepare_style.sh https://maps.your-domain.example
./scripts/start_stack.sh
```

بعد البناء الأول قد يحتاج Valhalla وقتًا لإنشاء routing graph.

## الربط مع التطبيق
عدّل `assets/config/app_config.json`:

```json
{
  "apiBaseUrl": "https://api.your-domain.example",
  "routingBaseUrl": "https://maps.your-domain.example/routing",
  "mapStyleUrl": "https://maps.your-domain.example/styles/yemen-light.json"
}
```

### ملاحظة الخطوط على الخريطة
ملف style يحتوي placeholders لمصدر glyphs/sprites. لا توجد ملفات خطوط مرفقة. جهّز glyph service في السيرفر أو استخدم style جاهز يدعم العربية. لا يؤثر هذا على خطوط واجهة Flutter نفسها.
