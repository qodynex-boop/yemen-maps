# معمارية خرائط اليمن

## التطبيق
Flutter Android + MapLibre + GPS + Arabic TTS.

- `HomeScreen`: مطابق للتصميم المرجعي قدر الإمكان.
- `SearchScreen`: بحث عام أو حسب القسم.
- `MapScreen`: خريطة اليمن الحقيقية.
- `NavigationScreen`: حساب مسار + تتبع GPS + خط المسار + إرشادات صوتية عربية.
- `PlaceService`: نقطة الربط الوحيدة مع API البحث.
- `RoutingService`: نقطة الربط الوحيدة مع Valhalla.

## الخرائط
- بيانات الطرق والمناطق: OpenStreetMap/Geofabrik.
- ملف التوجيه: `yemen-latest.osm.pbf`.
- ملف العرض الجاهز: `yemen-shortbread-1.0.mbtiles`.
- عرض الخرائط: Martin + MapLibre.

## التوجيه
Valhalla على السيرفر. التطبيق يرسل نقطة البداية والنهاية ونوع النقل.

## الصوت العربي
الصوت نفسه من Android TTS ولا نوزع ملفات صوت. التطبيق يولد النص العربي محليًا من نوع المناورة، لذلك لا يعتمد على توفر تعريب Valhalla.

## وسائط النقل
- سيارة: Valhalla `auto`
- مشي: `pedestrian`
- دراجة: `bicycle`
- باص: مؤقتًا مسار `auto` حتى توفير بيانات نقل عام GTFS حقيقية.
