# إعداد Android المطلوب

بعد تشغيل `flutter create --platforms=android .` تأكد من وجود التالي في `android/app/src/main/AndroidManifest.xml` خارج وداخل `<manifest>` بالشكل الصحيح:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />

<queries>
    <intent>
        <action android:name="android.intent.action.TTS_SERVICE" />
    </intent>
</queries>
```

لا نطلب Background Location في النسخة الأولى لأن الملاحة تعمل والشاشة/التطبيق في الواجهة. إذا أضيفت ملاحة بالخلفية لاحقًا، طبّق متطلبات Android الخاصة بخدمة foreground/location بدل طلب صلاحيات إضافية بلا حاجة.
