#!/usr/bin/env bash
set -euo pipefail
# Run only on a machine that has Flutter installed.
# It creates missing Android platform files without replacing lib/assets/server.
flutter create --platforms=android --org com.qodynex --project-name yemen_maps .
flutter pub get

echo "Now ensure android/app/src/main/AndroidManifest.xml includes INTERNET and location permissions."
