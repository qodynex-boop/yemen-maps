import 'package:maplibre_gl/maplibre_gl.dart';

List<LatLng> decodePolyline6(String encoded) {
  final points = <LatLng>[];
  var index = 0;
  var lat = 0;
  var lon = 0;

  while (index < encoded.length) {
    var result = 0;
    var shift = 0;
    int byte;
    do {
      byte = encoded.codeUnitAt(index++) - 63;
      result |= (byte & 0x1f) << shift;
      shift += 5;
    } while (byte >= 0x20 && index < encoded.length);
    final dLat = (result & 1) != 0 ? ~(result >> 1) : (result >> 1);
    lat += dLat;

    result = 0;
    shift = 0;
    do {
      byte = encoded.codeUnitAt(index++) - 63;
      result |= (byte & 0x1f) << shift;
      shift += 5;
    } while (byte >= 0x20 && index < encoded.length);
    final dLon = (result & 1) != 0 ? ~(result >> 1) : (result >> 1);
    lon += dLon;

    points.add(LatLng(lat / 1e6, lon / 1e6));
  }
  return points;
}
