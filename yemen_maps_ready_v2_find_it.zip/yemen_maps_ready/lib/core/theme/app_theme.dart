import 'package:flutter/material.dart';

class AppTheme {
  static const navy = Color(0xFF0A1D46);
  static const blue = Color(0xFF1478F5);
  static const bg = Color(0xFFF8FAFD);
  static const muted = Color(0xFF7A8498);

  static ThemeData get light {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(
        seedColor: blue,
        primary: blue,
        surface: Colors.white,
      ),
      fontFamily: null,
      textTheme: const TextTheme(
        headlineMedium: TextStyle(fontWeight: FontWeight.w800, color: navy),
        titleLarge: TextStyle(fontWeight: FontWeight.w800, color: navy),
        titleMedium: TextStyle(fontWeight: FontWeight.w700, color: navy),
        bodyLarge: TextStyle(color: navy),
        bodyMedium: TextStyle(color: muted),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(22),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(22),
          borderSide: BorderSide(color: Colors.black.withValues(alpha: .04)),
        ),
      ),
    );
  }
}
