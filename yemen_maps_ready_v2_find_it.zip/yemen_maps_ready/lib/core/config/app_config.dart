import 'dart:convert';
import 'package:flutter/services.dart';

class AppConfig {
  const AppConfig({
    required this.apiBaseUrl,
    required this.routingBaseUrl,
    required this.mapStyleUrl,
    required this.defaultLatitude,
    required this.defaultLongitude,
    required this.defaultZoom,
    required this.arabicTtsLocale,
  });

  final String apiBaseUrl;
  final String routingBaseUrl;
  final String mapStyleUrl;
  final double defaultLatitude;
  final double defaultLongitude;
  final double defaultZoom;
  final String arabicTtsLocale;

  static Future<AppConfig> load() async {
    final raw = await rootBundle.loadString('assets/config/app_config.json');
    final json = jsonDecode(raw) as Map<String, dynamic>;
    return AppConfig(
      apiBaseUrl: json['apiBaseUrl'] as String,
      routingBaseUrl: json['routingBaseUrl'] as String,
      mapStyleUrl: json['mapStyleUrl'] as String,
      defaultLatitude: (json['defaultLatitude'] as num).toDouble(),
      defaultLongitude: (json['defaultLongitude'] as num).toDouble(),
      defaultZoom: (json['defaultZoom'] as num).toDouble(),
      arabicTtsLocale: json['arabicTtsLocale'] as String? ?? 'ar-SA',
    );
  }
}
