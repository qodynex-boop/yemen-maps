import 'package:maplibre_gl/maplibre_gl.dart';

class Place {
  const Place({
    required this.id,
    required this.name,
    required this.category,
    required this.position,
    this.address,
    this.distanceMeters,
  });

  final String id;
  final String name;
  final String category;
  final LatLng position;
  final String? address;
  final double? distanceMeters;

  factory Place.fromJson(Map<String, dynamic> json) {
    return Place(
      id: json['id'].toString(),
      name: json['name'] as String? ?? 'مكان بدون اسم',
      category: json['category'] as String? ?? 'other',
      position: LatLng(
        (json['latitude'] as num).toDouble(),
        (json['longitude'] as num).toDouble(),
      ),
      address: json['address'] as String?,
      distanceMeters: (json['distanceMeters'] as num?)?.toDouble(),
    );
  }
}
