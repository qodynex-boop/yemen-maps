import 'package:dio/dio.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import '../models/place.dart';

class PlaceService {
  PlaceService(String baseUrl)
      : _dio = Dio(BaseOptions(
          baseUrl: baseUrl,
          connectTimeout: const Duration(seconds: 8),
          receiveTimeout: const Duration(seconds: 15),
        ));

  final Dio _dio;

  Future<List<Place>> search({
    required String query,
    String? category,
    LatLng? around,
  }) async {
    final response = await _dio.get<List<dynamic>>(
      '/v1/search',
      queryParameters: {
        'q': query,
        if (category != null) 'category': category,
        if (around != null) 'lat': around.latitude,
        if (around != null) 'lon': around.longitude,
      },
    );
    return (response.data ?? const [])
        .map((e) => Place.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<List<Place>> nearby({
    required String category,
    required LatLng around,
    int limit = 30,
  }) async {
    final response = await _dio.get<List<dynamic>>(
      '/v1/nearby',
      queryParameters: {
        'category': category,
        'lat': around.latitude,
        'lon': around.longitude,
        'limit': limit,
      },
    );
    return (response.data ?? const [])
        .map((e) => Place.fromJson(e as Map<String, dynamic>))
        .toList();
  }
}
