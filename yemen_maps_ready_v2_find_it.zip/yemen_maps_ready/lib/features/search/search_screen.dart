import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import '../../core/config/app_config.dart';
import '../navigation/models/transport_mode.dart';
import '../navigation/navigation_screen.dart';
import 'models/place.dart';
import 'services/place_service.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({
    super.key,
    required this.config,
    required this.mode,
    this.initialCategory,
  });
  final AppConfig config;
  final TransportMode mode;
  final String? initialCategory;

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  late final PlaceService _service;
  final _controller = TextEditingController();
  bool _loading = false;
  String? _error;
  List<Place> _results = const [];

  @override
  void initState() {
    super.initState();
    _service = PlaceService(widget.config.apiBaseUrl);
    if (widget.initialCategory != null) _loadNearby();
  }

  Future<LatLng> _currentOrDefault() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) throw Exception();
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) throw Exception();
      final p = await Geolocator.getCurrentPosition();
      return LatLng(p.latitude, p.longitude);
    } catch (_) {
      return LatLng(widget.config.defaultLatitude, widget.config.defaultLongitude);
    }
  }

  Future<void> _loadNearby() async {
    setState(() { _loading = true; _error = null; });
    try {
      final around = await _currentOrDefault();
      final data = await _service.nearby(category: widget.initialCategory!, around: around);
      if (mounted) setState(() => _results = data);
    } catch (_) {
      if (mounted) setState(() => _error = 'تعذر جلب الأماكن الآن. بعد ربط السيرفر ستظهر النتائج هنا.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _search() async {
    final q = _controller.text.trim();
    if (q.isEmpty && widget.initialCategory == null) return;
    setState(() { _loading = true; _error = null; });
    try {
      final around = await _currentOrDefault();
      final data = await _service.search(query: q, category: widget.initialCategory, around: around);
      if (mounted) setState(() => _results = data);
    } catch (_) {
      if (mounted) setState(() => _error = 'تعذر الاتصال بخدمة البحث.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.initialCategory == null ? 'البحث والتنقل' : _titleFor(widget.initialCategory!))),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
            child: TextField(
              controller: _controller,
              autofocus: widget.initialCategory == null,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _search(),
              decoration: InputDecoration(
                hintText: 'اكتب اسم المكان، الشارع، الحي أو النشاط',
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: IconButton(onPressed: _search, icon: const Icon(Icons.near_me_rounded)),
              ),
            ),
          ),
          if (_loading) const LinearProgressIndicator(minHeight: 2),
          if (_error != null)
            Padding(padding: const EdgeInsets.all(18), child: Text(_error!, textAlign: TextAlign.center)),
          Expanded(
            child: _results.isEmpty && !_loading
                ? const _EmptySearch()
                : ListView.separated(
                    padding: const EdgeInsets.all(12),
                    itemCount: _results.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, index) {
                      final p = _results[index];
                      return ListTile(
                        leading: const CircleAvatar(child: Icon(Icons.place_rounded)),
                        title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: Text(p.address ?? _titleFor(p.category)),
                        trailing: const Icon(Icons.chevron_left_rounded),
                        onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => NavigationScreen(config: widget.config, destination: p.position, destinationName: p.name, initialMode: widget.mode),
                        )),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  String _titleFor(String key) => const {
        'food': 'مطاعم وكافيهات',
        'fuel': 'محطات الوقود',
        'school': 'المدارس',
        'health': 'المراكز الصحية',
        'government': 'المرافق الحكومية',
        'parks': 'الحدائق',
      }[key] ?? 'أماكن';
}

class _EmptySearch extends StatelessWidget {
  const _EmptySearch();
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.travel_explore_rounded, size: 76, color: Color(0xFF1478F5)),
            SizedBox(height: 12),
            Text('ابحث عن أي مكان في اليمن', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
            SizedBox(height: 7),
            Text('الاسم، الحي، الشارع، المطعم، المدرسة أو أي نشاط آخر.', textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
