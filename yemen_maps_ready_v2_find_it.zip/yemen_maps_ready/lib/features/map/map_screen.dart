import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import '../../core/config/app_config.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key, required this.config, required this.onBackHome});
  final AppConfig config;
  final VoidCallback onBackHome;

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  MapLibreMapController? _controller;

  Future<void> _locate() async {
    try {
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) return;
      final p = await Geolocator.getCurrentPosition();
      await _controller?.animateCamera(CameraUpdate.newLatLngZoom(LatLng(p.latitude, p.longitude), 15));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          MapLibreMap(
            styleString: widget.config.mapStyleUrl,
            initialCameraPosition: CameraPosition(
              target: LatLng(widget.config.defaultLatitude, widget.config.defaultLongitude),
              zoom: widget.config.defaultZoom,
            ),
            myLocationEnabled: true,
            myLocationTrackingMode: MyLocationTrackingMode.none,
            compassEnabled: true,
            onMapCreated: (c) => _controller = c,
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  IconButton.filled(onPressed: widget.onBackHome, icon: const Icon(Icons.arrow_forward_rounded)),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Card(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 15),
                        child: Row(children: [Icon(Icons.search_rounded), SizedBox(width: 9), Text('ابحث في الخريطة', style: TextStyle(fontWeight: FontWeight.w800))]),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            left: 16,
            bottom: 22,
            child: FloatingActionButton(onPressed: _locate, child: const Icon(Icons.my_location_rounded)),
          ),
        ],
      ),
    );
  }
}
