import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../models/route_model.dart';

class NavigationTtsService {
  NavigationTtsService(this.locale);

  final String locale;
  final FlutterTts _tts = FlutterTts();
  Map<String, String> _phrases = const {};

  Future<void> initialize() async {
    final raw = await rootBundle.loadString('assets/navigation/ar_phrases.json');
    _phrases = (jsonDecode(raw) as Map<String, dynamic>)
        .map((key, value) => MapEntry(key, value.toString()));
    final preferred = await _tts.isLanguageAvailable(locale);
    if (preferred == true) {
      await _tts.setLanguage(locale);
    } else {
      await _tts.setLanguage('ar');
    }
    await _tts.setSpeechRate(0.46);
    await _tts.setPitch(1.0);
    await _tts.setVolume(1.0);
  }

  Future<void> stop() => _tts.stop();

  Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;
    await _tts.stop();
    await _tts.speak(text);
  }

  String phraseFor(RouteManeuver maneuver, {double? remainingMeters}) {
    final key = switch (maneuver.type) {
      1 || 2 || 3 => 'start',
      4 || 5 || 6 => 'destination',
      8 => 'continue',
      9 => 'slight_right',
      10 => 'right',
      11 => 'sharp_right',
      12 => 'uturn_right',
      13 => 'uturn_left',
      14 => 'sharp_left',
      15 => 'left',
      16 => 'slight_left',
      17 => 'ramp_straight',
      18 => 'ramp_right',
      19 => 'ramp_left',
      20 => 'exit_right',
      21 => 'exit_left',
      22 => 'stay_straight',
      23 => 'stay_right',
      24 => 'stay_left',
      25 => 'merge',
      26 => 'roundabout_enter',
      27 => 'roundabout_exit',
      _ => 'continue',
    };

    final street = maneuver.streetNames.isEmpty ? '' : ' إلى ${maneuver.streetNames.first}';
    final distance = remainingMeters == null ? '' : ' ${_distanceText(remainingMeters)}';
    return (_phrases[key] ?? maneuver.instruction)
        .replaceAll('{street}', street)
        .replaceAll('{distance}', distance)
        .replaceAll('{exit}', (maneuver.roundaboutExitCount ?? 1).toString());
  }

  String _distanceText(double meters) {
    if (meters < 80) return 'الآن';
    if (meters < 1000) {
      final rounded = (meters / 50).round() * 50;
      return 'بعد $rounded متر';
    }
    final km = meters / 1000;
    return km < 10
        ? 'بعد ${km.toStringAsFixed(1)} كيلومتر'
        : 'بعد ${km.round()} كيلومتر';
  }
}
