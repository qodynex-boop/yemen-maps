import 'package:dio/dio.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import '../models/route_model.dart';
import '../models/transport_mode.dart';

class RoutingService {
  RoutingService(String baseUrl)
      : _dio = Dio(BaseOptions(
          baseUrl: baseUrl,
          connectTimeout: const Duration(seconds: 12),
          receiveTimeout: const Duration(seconds: 25),
          headers: const {'Content-Type': 'application/json'},
        ));

  final Dio _dio;

  Future<NavigationRoute> route({
    required LatLng origin,
    required LatLng destination,
    required TransportMode mode,
  }) async {
    final response = await _dio.post<Map<String, dynamic>>(
      '/route',
      data: {
        'locations': [
          {'lat': origin.latitude, 'lon': origin.longitude},
          {'lat': destination.latitude, 'lon': destination.longitude},
        ],
        'costing': mode.valhallaCosting,
        'units': 'kilometers',
        'directions_options': {
          // We generate Arabic instructions locally from maneuver types.
          'language': 'en-US',
          'units': 'kilometers',
        },
      },
    );
    return NavigationRoute.fromValhalla(response.data ?? const {});
  }
}
