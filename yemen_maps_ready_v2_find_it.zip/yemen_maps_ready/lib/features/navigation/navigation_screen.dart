import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import '../../core/config/app_config.dart';
import 'models/route_model.dart';
import 'models/transport_mode.dart';
import 'services/navigation_tts_service.dart';
import 'services/routing_service.dart';

class NavigationScreen extends StatefulWidget {
  const NavigationScreen({
    super.key,
    required this.config,
    required this.destination,
    required this.destinationName,
    required this.initialMode,
  });
  final AppConfig config;
  final LatLng destination;
  final String destinationName;
  final TransportMode initialMode;

  @override
  State<NavigationScreen> createState() => _NavigationScreenState();
}

class _NavigationScreenState extends State<NavigationScreen> {
  late TransportMode _mode;
  late final RoutingService _routing;
  late final NavigationTtsService _tts;
  MapLibreMapController? _map;
  NavigationRoute? _route;
  Position? _position;
  bool _loading = true;
  String? _error;
  StreamSubscription<Position>? _sub;
  int _maneuverIndex = 0;
  int _lastAnnouncementBand = -1;
  int _offRouteCount = 0;
  bool _recalculating = false;

  @override
  void initState() {
    super.initState();
    _mode = widget.initialMode;
    _routing = RoutingService(widget.config.routingBaseUrl);
    _tts = NavigationTtsService(widget.config.arabicTtsLocale);
    _start();
  }

  Future<void> _start() async {
    await _tts.initialize();
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
      setState(() { _loading = false; _error = 'يلزم السماح بالوصول إلى الموقع لبدء الملاحة.'; });
      return;
    }
    try {
      final p = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.best),
      );
      _position = p;
      await _calculateRoute();
      _sub = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.bestForNavigation, distanceFilter: 8),
      ).listen(_onPosition);
    } catch (_) {
      if (mounted) setState(() { _loading = false; _error = 'تعذر بدء الملاحة. تأكد من GPS وخدمة المسارات.'; });
    }
  }

  Future<void> _calculateRoute() async {
    final p = _position;
    if (p == null) return;
    setState(() { _loading = true; _error = null; });
    try {
      final r = await _routing.route(
        origin: LatLng(p.latitude, p.longitude),
        destination: widget.destination,
        mode: _mode,
      );
      _route = r;
      _maneuverIndex = 0;
      _lastAnnouncementBand = -1;
      if (mounted) setState(() => _loading = false);
      await _drawRoute();
      if (r.maneuvers.isNotEmpty) await _tts.speak(_tts.phraseFor(r.maneuvers.first));
    } catch (_) {
      if (mounted) setState(() { _loading = false; _error = 'تعذر حساب المسار. سيتم العمل بعد ربط Valhalla على السيرفر.'; });
    }
  }

  void _onPosition(Position p) {
    _position = p;
    final route = _route;
    if (route == null || route.maneuvers.isEmpty) return;
    final idx = _maneuverIndex.clamp(0, route.maneuvers.length - 1);
    final maneuver = route.maneuvers[idx];
    if (route.points.isEmpty) return;
    final shapeIndex = maneuver.endShapeIndex.clamp(0, route.points.length - 1);
    final target = route.points[shapeIndex];
    final meters = Geolocator.distanceBetween(p.latitude, p.longitude, target.latitude, target.longitude);
    final band = meters < 45 ? 0 : meters < 180 ? 1 : meters < 550 ? 2 : 3;
    if (band < 3 && band != _lastAnnouncementBand) {
      _lastAnnouncementBand = band;
      _tts.speak(_tts.phraseFor(maneuver, remainingMeters: meters));
    }
    if (meters < 30 && _maneuverIndex < route.maneuvers.length - 1) {
      _maneuverIndex++;
      _lastAnnouncementBand = -1;
      if (mounted) setState(() {});
    }

    _checkOffRoute(p, route);
  }


  void _checkOffRoute(Position p, NavigationRoute route) {
    if (_recalculating || route.points.isEmpty) return;
    final stride = (route.points.length / 250).ceil().clamp(1, 9999);
    var nearest = double.infinity;
    for (var i = 0; i < route.points.length; i += stride) {
      final point = route.points[i];
      final d = Geolocator.distanceBetween(
        p.latitude, p.longitude, point.latitude, point.longitude,
      );
      if (d < nearest) nearest = d;
    }
    if (nearest > 90) {
      _offRouteCount++;
    } else {
      _offRouteCount = 0;
    }
    if (_offRouteCount >= 3) {
      _offRouteCount = 0;
      _recalculating = true;
      _tts.speak('جاري إعادة حساب المسار');
      _calculateRoute().whenComplete(() => _recalculating = false);
    }
  }

  Future<void> _drawRoute() async {
    final map = _map;
    final route = _route;
    if (map == null || route == null || route.points.isEmpty) return;
    if (map.lines.isNotEmpty) {
      await map.removeLines(map.lines.toList());
    }
    await map.addLine(LineOptions(geometry: route.points, lineColor: '#1478F5', lineWidth: 6.0, lineOpacity: .95));
    var minLat = route.points.first.latitude;
    var maxLat = route.points.first.latitude;
    var minLon = route.points.first.longitude;
    var maxLon = route.points.first.longitude;
    for (final point in route.points.skip(1)) {
      if (point.latitude < minLat) minLat = point.latitude;
      if (point.latitude > maxLat) maxLat = point.latitude;
      if (point.longitude < minLon) minLon = point.longitude;
      if (point.longitude > maxLon) maxLon = point.longitude;
    }
    final bounds = LatLngBounds(
      southwest: LatLng(minLat, minLon),
      northeast: LatLng(maxLat, maxLon),
    );
    await map.animateCamera(CameraUpdate.newLatLngBounds(bounds, left: 55, top: 170, right: 55, bottom: 210));
  }

  @override
  void dispose() {
    _sub?.cancel();
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final maneuver = (_route != null && _route!.maneuvers.isNotEmpty)
        ? _route!.maneuvers[_maneuverIndex.clamp(0, _route!.maneuvers.length - 1)]
        : null;
    return Scaffold(
      body: Stack(
        children: [
          MapLibreMap(
            styleString: widget.config.mapStyleUrl,
            initialCameraPosition: CameraPosition(target: widget.destination, zoom: 13),
            myLocationEnabled: true,
            myLocationTrackingMode: MyLocationTrackingMode.trackingGps,
            onMapCreated: (c) { _map = c; _drawRoute(); },
            onStyleLoadedCallback: _drawRoute,
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  IconButton.filled(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(maneuver == null ? 'جاري تجهيز الطريق...' : _tts.phraseFor(maneuver), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                            const SizedBox(height: 3),
                            Text(widget.destinationName, maxLines: 1, overflow: TextOverflow.ellipsis),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (_loading) const Center(child: CircularProgressIndicator()),
          if (_error != null)
            Center(
              child: Container(
                margin: const EdgeInsets.all(28),
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
                child: Text(_error!, textAlign: TextAlign.center),
              ),
            ),
          if (_route != null)
            Positioned(
              left: 14,
              right: 14,
              bottom: 22,
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Expanded(child: _Metric(value: '${_route!.durationSeconds ~/ 60}', label: 'دقيقة')),
                      const VerticalDivider(),
                      Expanded(child: _Metric(value: _route!.distanceKm.toStringAsFixed(1), label: 'كم')),
                      const VerticalDivider(),
                      Expanded(child: _Metric(value: _mode.label, label: 'وسيلة النقل')),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({required this.value, required this.label});
  final String value;
  final String label;
  @override
  Widget build(BuildContext context) => Column(children: [Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), Text(label, style: const TextStyle(fontSize: 12))]);
}
