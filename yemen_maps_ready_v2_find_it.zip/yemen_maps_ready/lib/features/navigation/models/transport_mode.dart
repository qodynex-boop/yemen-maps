import 'package:flutter/material.dart';

enum TransportMode { car, walking, bicycle, bus }

extension TransportModeX on TransportMode {
  String get label => switch (this) {
        TransportMode.car => 'سيارة',
        TransportMode.walking => 'مشي',
        TransportMode.bicycle => 'دراجة',
        TransportMode.bus => 'باص',
      };

  IconData get icon => switch (this) {
        TransportMode.car => Icons.directions_car_rounded,
        TransportMode.walking => Icons.directions_walk_rounded,
        TransportMode.bicycle => Icons.pedal_bike_rounded,
        TransportMode.bus => Icons.directions_bus_rounded,
      };

  String get valhallaCosting => switch (this) {
        TransportMode.car => 'auto',
        TransportMode.walking => 'pedestrian',
        TransportMode.bicycle => 'bicycle',
        // Until Yemen GTFS/transit data is added, bus follows the drivable road graph.
        TransportMode.bus => 'auto',
      };
}
