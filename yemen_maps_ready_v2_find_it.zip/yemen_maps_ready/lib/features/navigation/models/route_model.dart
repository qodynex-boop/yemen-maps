import 'package:maplibre_gl/maplibre_gl.dart';
import '../../../core/utils/polyline6.dart';

class RouteManeuver {
  const RouteManeuver({
    required this.type,
    required this.instruction,
    required this.lengthKm,
    required this.timeSeconds,
    required this.beginShapeIndex,
    required this.endShapeIndex,
    required this.streetNames,
    this.roundaboutExitCount,
  });

  final int type;
  final String instruction;
  final double lengthKm;
  final int timeSeconds;
  final int beginShapeIndex;
  final int endShapeIndex;
  final List<String> streetNames;
  final int? roundaboutExitCount;

  factory RouteManeuver.fromJson(Map<String, dynamic> json) {
    return RouteManeuver(
      type: json['type'] as int? ?? 0,
      instruction: json['instruction'] as String? ?? '',
      lengthKm: (json['length'] as num? ?? 0).toDouble(),
      timeSeconds: (json['time'] as num? ?? 0).round(),
      beginShapeIndex: json['begin_shape_index'] as int? ?? 0,
      endShapeIndex: json['end_shape_index'] as int? ?? 0,
      streetNames: (json['street_names'] as List<dynamic>? ?? const [])
          .map((e) => e.toString())
          .toList(),
      roundaboutExitCount: json['roundabout_exit_count'] as int?,
    );
  }
}

class NavigationRoute {
  const NavigationRoute({
    required this.points,
    required this.maneuvers,
    required this.distanceKm,
    required this.durationSeconds,
  });

  final List<LatLng> points;
  final List<RouteManeuver> maneuvers;
  final double distanceKm;
  final int durationSeconds;

  factory NavigationRoute.fromValhalla(Map<String, dynamic> json) {
    final trip = (json['trip'] as Map<String, dynamic>?) ?? const {};
    final summary = (trip['summary'] as Map<String, dynamic>?) ?? const {};
    final legs = (trip['legs'] as List<dynamic>? ?? const []);
    final allPoints = <LatLng>[];
    final allManeuvers = <RouteManeuver>[];

    for (final item in legs) {
      final leg = item as Map<String, dynamic>;
      final shape = leg['shape'] as String?;
      if (shape != null && shape.isNotEmpty) {
        final decoded = decodePolyline6(shape);
        if (allPoints.isNotEmpty && decoded.isNotEmpty) decoded.removeAt(0);
        allPoints.addAll(decoded);
      }
      final maneuvers = leg['maneuvers'] as List<dynamic>? ?? const [];
      allManeuvers.addAll(
        maneuvers.map((e) => RouteManeuver.fromJson(e as Map<String, dynamic>)),
      );
    }

    return NavigationRoute(
      points: allPoints,
      maneuvers: allManeuvers,
      distanceKm: (summary['length'] as num? ?? 0).toDouble(),
      durationSeconds: (summary['time'] as num? ?? 0).round(),
    );
  }
}
