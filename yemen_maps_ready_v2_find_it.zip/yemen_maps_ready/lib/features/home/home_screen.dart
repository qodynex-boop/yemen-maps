import 'package:flutter/material.dart';
import '../../core/config/app_config.dart';
import '../map/map_screen.dart';
import '../find_it/find_it_screen.dart';
import '../navigation/models/transport_mode.dart';
import '../search/search_screen.dart';
import 'widgets/category_grid.dart';
import 'widgets/navigation_hero_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.config});
  final AppConfig config;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  TransportMode _mode = TransportMode.car;
  int _tab = 0;

  void _openFindIt() {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => FindItScreen(config: widget.config, initialMode: _mode),
    ));
  }

  void _openSearch([String? category]) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => SearchScreen(config: widget.config, mode: _mode, initialCategory: category),
    ));
  }

  @override
  Widget build(BuildContext context) {
    if (_tab == 1) {
      return MapScreen(config: widget.config, onBackHome: () => setState(() => _tab = 0));
    }
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: CustomScrollView(
                slivers: [
                  SliverToBoxAdapter(child: _Header()),
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
                    sliver: SliverList.list(children: [
                      NavigationHeroCard(
                        mode: _mode,
                        onModeChanged: (m) => setState(() => _mode = m),
                        onSearch: _openSearch,
                      ),
                      const SizedBox(height: 14),
                      _FindItCard(onTap: _openFindIt),
                      const SizedBox(height: 24),
                      Row(
                        children: [
                          const Expanded(child: Text('الأقسام الرئيسية', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: Color(0xFF091B42)))),
                          TextButton.icon(
                            onPressed: () => _openSearch(),
                            icon: const Icon(Icons.chevron_left_rounded),
                            label: const Text('عرض الكل'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 9),
                      CategoryGrid(onTap: (item) {
                        if (item.keyName == 'navigate' || item.keyName == 'more') {
                          _openSearch();
                        } else {
                          _openSearch(item.keyName);
                        }
                      }),
                      const SizedBox(height: 20),
                      _ExploreCard(onTap: _openSearch),
                      const SizedBox(height: 20),
                    ]),
                  ),
                ],
              ),
            ),
            NavigationBar(
              height: 72,
              selectedIndex: _tab,
              onDestinationSelected: (i) {
                if (i == 0 || i == 1) setState(() => _tab = i);
              },
              destinations: const [
                NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'الرئيسية'),
                NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map_rounded), label: 'الخريطة'),
                NavigationDestination(icon: Icon(Icons.bookmark_border_rounded), label: 'المحفوظة'),
                NavigationDestination(icon: Icon(Icons.person_outline_rounded), label: 'حسابي'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 12),
      child: Row(
        children: [
          _RoundButton(icon: Icons.notifications_none_rounded, badge: true, onTap: () {}),
          const Expanded(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.location_on_rounded, color: Color(0xFFF04747), size: 37),
                    SizedBox(width: 4),
                    Text('خرائط اليمن', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: Color(0xFF0A1D46))),
                  ],
                ),
                Text('اكتشف اليمن .. بكل سهولة', style: TextStyle(color: Color(0xFF858B99), fontSize: 14.5)),
              ],
            ),
          ),
          _RoundButton(icon: Icons.settings_rounded, onTap: () {}),
        ],
      ),
    );
  }
}

class _RoundButton extends StatelessWidget {
  const _RoundButton({required this.icon, required this.onTap, this.badge = false});
  final IconData icon;
  final VoidCallback onTap;
  final bool badge;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        IconButton.filledTonal(onPressed: onTap, icon: Icon(icon), style: IconButton.styleFrom(backgroundColor: const Color(0xFFF1F3F7))),
        if (badge) Positioned(right: 3, top: 3, child: Container(width: 9, height: 9, decoration: const BoxDecoration(color: Color(0xFFEF4444), shape: BoxShape.circle))),
      ],
    );
  }
}

class _ExploreCard extends StatelessWidget {
  const _ExploreCard({required this.onTap});
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFE8ECF3)),
      ),
      child: Row(
        children: [
          Container(
            width: 112,
            height: 108,
            decoration: BoxDecoration(color: const Color(0xFFE8F4FF), borderRadius: BorderRadius.circular(22)),
            child: const Stack(alignment: Alignment.center, children: [
              Icon(Icons.map_rounded, size: 78, color: Color(0xFFB8DDFC)),
              Icon(Icons.search_rounded, size: 70, color: Color(0xFF1478F5)),
            ]),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('ابحث عن أي مكان آخر', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: Color(0xFF091B42))),
                const SizedBox(height: 5),
                const Text('اكتشف الأماكن القريبة منك وتصفح النتائج ثم ابدأ التنقل بالطريقة التي تناسبك.', style: TextStyle(height: 1.5, color: Color(0xFF7A8498))),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(onPressed: onTap, icon: const Icon(Icons.search_rounded), label: const Text('ابدأ البحث')),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


class _FindItCard extends StatelessWidget {
  const _FindItCard({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Ink(
        padding: const EdgeInsets.all(17),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFE8F3FF), Color(0xFFF1ECFF)],
            begin: Alignment.centerRight,
            end: Alignment.centerLeft,
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: const Color(0xFFDCE7F7)),
        ),
        child: Row(
          children: [
            Container(
              width: 58,
              height: 58,
              decoration: BoxDecoration(color: Colors.white.withValues(alpha: .86), borderRadius: BorderRadius.circular(19)),
              child: const Icon(Icons.saved_search_rounded, color: Color(0xFF1478F5), size: 34),
            ),
            const SizedBox(width: 13),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('وين ألاقيه؟', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: Color(0xFF091B42))),
                  SizedBox(height: 3),
                  Text('ابحث عن منتج أو خدمة: بطارية، شاشة، دواء، فني، سباك وأكثر.', style: TextStyle(height: 1.45, color: Color(0xFF66738A))),
                ],
              ),
            ),
            const SizedBox(width: 8),
            const CircleAvatar(
              backgroundColor: Color(0xFF1478F5),
              foregroundColor: Colors.white,
              child: Icon(Icons.chevron_left_rounded),
            ),
          ],
        ),
      ),
    );
  }
}
