import 'package:flutter/material.dart';
import '../../navigation/models/transport_mode.dart';
import 'map_preview_painter.dart';

class NavigationHeroCard extends StatelessWidget {
  const NavigationHeroCard({
    super.key,
    required this.mode,
    required this.onModeChanged,
    required this.onSearch,
  });

  final TransportMode mode;
  final ValueChanged<TransportMode> onModeChanged;
  final VoidCallback onSearch;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(26),
      child: SizedBox(
        height: 295,
        child: Stack(
          children: [
            const Positioned.fill(child: CustomPaint(painter: MapPreviewPainter())),
            Positioned(
              top: 18,
              left: 16,
              right: 16,
              child: InkWell(
                onTap: onSearch,
                borderRadius: BorderRadius.circular(22),
                child: Container(
                  height: 62,
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: .08),
                        blurRadius: 24,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.near_me_rounded, color: Color(0xFF1478F5), size: 29),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'أين تريد الذهاب؟',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                        ),
                      ),
                      VerticalDivider(indent: 15, endIndent: 15),
                      SizedBox(width: 6),
                      Icon(Icons.search_rounded, size: 31, color: Color(0xFF3D4658)),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              top: 92,
              left: 14,
              right: 14,
              child: Row(
                children: TransportMode.values.map((m) {
                  final selected = m == mode;
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      child: GestureDetector(
                        onTap: () => onModeChanged(m),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          height: 48,
                          decoration: BoxDecoration(
                            color: selected ? const Color(0xFF1478F5) : Colors.white.withValues(alpha: .9),
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: Colors.white),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(m.icon, size: 22, color: selected ? Colors.white : const Color(0xFF17223A)),
                              const SizedBox(width: 6),
                              Flexible(
                                child: Text(
                                  m.label,
                                  maxLines: 1,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: selected ? Colors.white : const Color(0xFF17223A),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            Positioned(
              left: 62,
              bottom: 58,
              child: _Dot(color: const Color(0xFF1478F5)),
            ),
            Positioned(
              right: 116,
              bottom: 89,
              child: Column(
                children: [
                  const Icon(Icons.location_on_rounded, color: Color(0xFFEF4444), size: 44),
                  Container(width: 20, height: 5, decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(20))),
                ],
              ),
            ),
            Positioned(
              right: 18,
              bottom: 18,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
                child: const Row(
                  children: [
                    Icon(Icons.my_location_rounded, size: 19),
                    SizedBox(width: 6),
                    Text('صنعاء', style: TextStyle(fontWeight: FontWeight.w800)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Dot extends StatelessWidget {
  const _Dot({required this.color});
  final Color color;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 26,
      height: 26,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 5),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 7)],
      ),
    );
  }
}
