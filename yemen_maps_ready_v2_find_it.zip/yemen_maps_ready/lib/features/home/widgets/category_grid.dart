import 'package:flutter/material.dart';

class HomeCategory {
  const HomeCategory(this.title, this.keyName, this.icon, this.colors);
  final String title;
  final String keyName;
  final IconData icon;
  final List<Color> colors;
}

const homeCategories = [
  HomeCategory('التنقل إلى وجهة', 'navigate', Icons.directions_car_filled_rounded, [Color(0xFFDDF3FF), Color(0xFFBEE7FF)]),
  HomeCategory('مطاعم وكافيهات', 'food', Icons.restaurant_rounded, [Color(0xFFFFF0E2), Color(0xFFFFDDBD)]),
  HomeCategory('محطات الوقود', 'fuel', Icons.local_gas_station_rounded, [Color(0xFFFFE8E9), Color(0xFFFFC9CF)]),
  HomeCategory('المدارس', 'school', Icons.school_rounded, [Color(0xFFF1E8FF), Color(0xFFDDCAFF)]),
  HomeCategory('المراكز الصحية', 'health', Icons.local_hospital_rounded, [Color(0xFFE1FAF3), Color(0xFFC4F2E5)]),
  HomeCategory('المرافق الحكومية', 'government', Icons.account_balance_rounded, [Color(0xFFFFF5D6), Color(0xFFFFE49A)]),
  HomeCategory('الحدائق', 'parks', Icons.park_rounded, [Color(0xFFE5F9DF), Color(0xFFC9F1BF)]),
  HomeCategory('المزيد', 'more', Icons.grid_view_rounded, [Color(0xFFF0EFFF), Color(0xFFDAD8FF)]),
];

class CategoryGrid extends StatelessWidget {
  const CategoryGrid({super.key, required this.onTap});
  final ValueChanged<HomeCategory> onTap;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: homeCategories.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        mainAxisSpacing: 12,
        crossAxisSpacing: 10,
        childAspectRatio: .78,
      ),
      itemBuilder: (context, index) {
        final item = homeCategories[index];
        return InkWell(
          onTap: () => onTap(item),
          borderRadius: BorderRadius.circular(22),
          child: Ink(
            decoration: BoxDecoration(
              gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: item.colors),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(5, 13, 5, 9),
              child: Column(
                children: [
                  Container(
                    width: 49,
                    height: 49,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withValues(alpha: .48),
                    ),
                    child: Icon(item.icon, size: 29, color: _iconColor(index)),
                  ),
                  const SizedBox(height: 9),
                  Expanded(
                    child: Center(
                      child: Text(
                        item.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 12.4, height: 1.25, fontWeight: FontWeight.w800, color: Color(0xFF111B33)),
                      ),
                    ),
                  ),
                  Container(
                    width: 27,
                    height: 27,
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .62), shape: BoxShape.circle),
                    child: Icon(Icons.chevron_left_rounded, size: 19, color: _iconColor(index)),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Color _iconColor(int index) => const [
        Color(0xFF176FEA), Color(0xFFFF8A34), Color(0xFFEF4444), Color(0xFF7042E8),
        Color(0xFF19A77A), Color(0xFFD68A05), Color(0xFF159B55), Color(0xFF5C54E8),
      ][index];
}
