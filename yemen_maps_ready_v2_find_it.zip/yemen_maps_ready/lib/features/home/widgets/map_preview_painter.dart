import 'package:flutter/material.dart';

class MapPreviewPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFFF3F4F1);
    canvas.drawRect(Offset.zero & size, bg);

    final park = Paint()..color = const Color(0xFFDFF1D7);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(size.width * .58, 0, size.width * .22, size.height * .22),
        const Radius.circular(18),
      ),
      park,
    );
    final water = Paint()..color = const Color(0xFFB8E3F8);
    final waterPath = Path()
      ..moveTo(0, size.height * .35)
      ..quadraticBezierTo(size.width * .14, size.height * .44, size.width * .08, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(waterPath, water);

    final road = Paint()
      ..color = Colors.white
      ..strokeWidth = 5
      ..style = PaintingStyle.stroke;
    for (var i = 0; i < 10; i++) {
      final y = size.height * (.08 + i * .1);
      canvas.drawLine(Offset(0, y), Offset(size.width, y - 25), road);
    }
    for (var i = 0; i < 8; i++) {
      final x = size.width * (.08 + i * .13);
      canvas.drawLine(Offset(x, 0), Offset(x + 55, size.height), road);
    }

    final route = Paint()
      ..color = const Color(0xFF1478F5)
      ..strokeWidth = 3.2
      ..style = PaintingStyle.stroke;
    final p = Path()
      ..moveTo(size.width * .25, size.height * .72)
      ..cubicTo(
        size.width * .42,
        size.height * .45,
        size.width * .56,
        size.height * .86,
        size.width * .76,
        size.height * .55,
      );
    canvas.drawPath(p, route);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
