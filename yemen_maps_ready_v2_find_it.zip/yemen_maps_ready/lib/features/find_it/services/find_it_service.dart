import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import '../models/find_it_filters.dart';
import '../models/find_it_listing.dart';
import '../merchant/merchant_local_repository.dart';

class FindItSearchResponse {
  const FindItSearchResponse({required this.items, required this.isDemo});
  final List<FindItListing> items;
  final bool isDemo;
}

class FindItService {
  FindItService(this.apiBaseUrl) : _dio = Dio(BaseOptions(connectTimeout: const Duration(seconds: 4), receiveTimeout: const Duration(seconds: 7)));

  final String apiBaseUrl;
  final Dio _dio;

  Future<FindItSearchResponse> search({
    required String query,
    required LatLng around,
    required FindItFilters filters,
    required FindItSort sort,
  }) async {
    final trimmed = query.trim();
    if (trimmed.isEmpty) return const FindItSearchResponse(items: [], isDemo: false);

    try {
      final response = await _dio.get(
        '$apiBaseUrl/v1/market/search',
        queryParameters: {
          'q': trimmed,
          'lat': around.latitude,
          'lon': around.longitude,
          'sort': sort.apiValue,
          'governorate': filters.governorate,
          if (filters.district?.trim().isNotEmpty == true) 'district': filters.district!.trim(),
          if (filters.type != null) 'itemType': filters.type!.apiValue,
          if (filters.minPrice != null) 'minPrice': filters.minPrice,
          if (filters.maxPrice != null) 'maxPrice': filters.maxPrice,
          'maxDistanceKm': filters.maxDistanceKm,
          if (filters.onlyAvailable) 'availability': 'available',
        },
      );
      final payload = response.data;
      final rawItems = payload is List ? payload : (payload is Map<String, dynamic> ? payload['items'] as List<dynamic>? : null);
      if (rawItems == null) throw const FormatException('Unexpected market search payload');
      final items = rawItems
          .whereType<Map>()
          .map((e) => FindItListing.fromJson(Map<String, dynamic>.from(e)))
          .map((e) => e.distanceMeters == null ? e.copyWith(distanceMeters: _distance(around, e.position)) : e)
          .toList();
      return FindItSearchResponse(items: items, isDemo: false);
    } catch (_) {
      final local = await _searchLocal(trimmed, around, filters, sort);
      return FindItSearchResponse(items: local, isDemo: true);
    }
  }

  Future<List<FindItListing>> _searchLocal(
    String query,
    LatLng around,
    FindItFilters filters,
    FindItSort sort,
  ) async {
    final raw = await rootBundle.loadString('assets/find_it/demo_listings.json');
    final decoded = jsonDecode(raw) as List<dynamic>;
    final allItems = decoded
        .map((e) => FindItListing.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();

    // Include merchant drafts created on this device so the whole flow can be
    // tested before authentication/API sync is enabled.
    final merchantRepo = MerchantLocalRepository();
    final store = await merchantRepo.loadStore();
    if (store != null) {
      final merchantItems = await merchantRepo.loadItems();
      allItems.addAll(merchantItems.map((item) => FindItListing(
            id: item.id,
            merchantId: store.id,
            merchantName: store.name,
            itemName: item.name,
            type: item.type,
            category: item.category,
            price: item.price,
            currency: item.currency,
            availability: item.availability,
            governorate: store.governorate,
            district: store.district,
            address: store.address,
            position: store.position,
            phone: store.phone,
            whatsapp: store.whatsapp,
            openingHours: store.openingHours,
            description: item.description,
            updatedAt: item.updatedAt,
            isDemo: false,
          )));
    }

    final q = _normalize(query);
    var items = allItems
        .map((e) => e.copyWith(distanceMeters: _distance(around, e.position)))
        .where((item) {
          final haystack = _normalize([
            item.itemName,
            item.merchantName,
            item.category,
            item.district,
            item.description ?? '',
            ...item.searchAliases,
          ].join(' '));
          if (!haystack.contains(q)) return false;
          if (filters.governorate.trim().isNotEmpty && _normalize(item.governorate) != _normalize(filters.governorate)) return false;
          if (filters.district?.trim().isNotEmpty == true && !_normalize(item.district).contains(_normalize(filters.district!))) return false;
          if (filters.type != null && item.type != filters.type) return false;
          if (filters.onlyAvailable && item.availability != AvailabilityStatus.available) return false;
          if (filters.minPrice != null && (item.price == null || item.price! < filters.minPrice!)) return false;
          if (filters.maxPrice != null && (item.price == null || item.price! > filters.maxPrice!)) return false;
          if ((item.distanceMeters ?? double.infinity) > filters.maxDistanceKm * 1000) return false;
          return true;
        })
        .toList();

    items.sort((a, b) {
      switch (sort) {
        case FindItSort.nearest:
          return (a.distanceMeters ?? double.infinity).compareTo(b.distanceMeters ?? double.infinity);
        case FindItSort.cheapest:
          final ap = a.price ?? double.infinity;
          final bp = b.price ?? double.infinity;
          return ap.compareTo(bp);
        case FindItSort.latest:
          return b.updatedAt.compareTo(a.updatedAt);
        case FindItSort.availableFirst:
          final aRank = a.availability == AvailabilityStatus.available ? 0 : 1;
          final bRank = b.availability == AvailabilityStatus.available ? 0 : 1;
          final availabilityCompare = aRank.compareTo(bRank);
          if (availabilityCompare != 0) return availabilityCompare;
          return (a.distanceMeters ?? double.infinity).compareTo(b.distanceMeters ?? double.infinity);
      }
    });
    return items;
  }

  double _distance(LatLng origin, LatLng target) => Geolocator.distanceBetween(
        origin.latitude,
        origin.longitude,
        target.latitude,
        target.longitude,
      );

  String _normalize(String input) {
    var value = input.toLowerCase().trim();
    const replacements = {
      'أ': 'ا',
      'إ': 'ا',
      'آ': 'ا',
      'ى': 'ي',
      'ؤ': 'و',
      'ئ': 'ي',
      'ة': 'ه',
    };
    replacements.forEach((from, to) => value = value.replaceAll(from, to));
    value = value.replaceAll(RegExp(r'[\u064B-\u065F\u0670]'), '');
    value = value.replaceAll(RegExp(r'\s+'), ' ');
    return value;
  }
}
