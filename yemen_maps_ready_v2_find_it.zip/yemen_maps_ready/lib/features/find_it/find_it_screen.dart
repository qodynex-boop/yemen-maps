import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/config/app_config.dart';
import '../navigation/models/transport_mode.dart';
import '../navigation/navigation_screen.dart';
import 'find_it_map_screen.dart';
import 'merchant/merchant_dashboard_screen.dart';
import 'models/find_it_filters.dart';
import 'models/find_it_listing.dart';
import 'services/find_it_service.dart';
import 'widgets/find_it_filters_sheet.dart';
import 'widgets/find_it_result_card.dart';

class FindItScreen extends StatefulWidget {
  const FindItScreen({
    super.key,
    required this.config,
    required this.initialMode,
  });

  final AppConfig config;
  final TransportMode initialMode;

  @override
  State<FindItScreen> createState() => _FindItScreenState();
}

class _FindItScreenState extends State<FindItScreen> {
  final _controller = TextEditingController();
  late final FindItService _service;
  late TransportMode _mode;
  FindItFilters _filters = const FindItFilters();
  FindItSort _sort = FindItSort.nearest;
  List<FindItListing> _items = const [];
  bool _loading = false;
  bool _demo = false;
  String? _error;
  String _lastQuery = '';

  static const _examples = [
    'بطارية طاقة شمسية',
    'شاشة جوال',
    'قطعة غيار سيارة',
    'لابتوب',
    'دواء',
    'فني تكييف',
    'سباك',
    'كهربائي',
  ];

  @override
  void initState() {
    super.initState();
    _service = FindItService(widget.config.apiBaseUrl);
    _mode = widget.initialMode;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<LatLng> _currentOrDefault() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) throw Exception();
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) throw Exception();
      final p = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
      return LatLng(p.latitude, p.longitude);
    } catch (_) {
      return LatLng(widget.config.defaultLatitude, widget.config.defaultLongitude);
    }
  }

  Future<void> _search([String? query]) async {
    final q = (query ?? _controller.text).trim();
    if (q.isEmpty) return;
    if (query != null) _controller.text = query;
    FocusScope.of(context).unfocus();
    setState(() {
      _loading = true;
      _error = null;
      _lastQuery = q;
    });
    try {
      final around = await _currentOrDefault();
      final result = await _service.search(query: q, around: around, filters: _filters, sort: _sort);
      if (!mounted) return;
      setState(() {
        _items = result.items;
        _demo = result.isDemo;
      });
    } catch (_) {
      if (mounted) setState(() => _error = 'تعذر تنفيذ البحث الآن.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _changeSort(FindItSort sort) async {
    setState(() => _sort = sort);
    if (_lastQuery.isNotEmpty) await _search(_lastQuery);
  }

  Future<void> _openFilters() async {
    final result = await showModalBottomSheet<FindItFilters>(
      context: context,
      isScrollControlled: true,
      showDragHandle: false,
      builder: (_) => FindItFiltersSheet(initial: _filters),
    );
    if (result == null) return;
    setState(() => _filters = result);
    if (_lastQuery.isNotEmpty) await _search(_lastQuery);
  }

  void _navigate(FindItListing item) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => NavigationScreen(
          config: widget.config,
          destination: item.position,
          destinationName: '${item.merchantName} - ${item.itemName}',
          initialMode: _mode,
        ),
      ),
    );
  }

  void _showOnMap(FindItListing item) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => FindItMapScreen(config: widget.config, listing: item, mode: _mode)),
    );
  }

  Future<void> _call(String phone) async {
    final uri = Uri(scheme: 'tel', path: phone);
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _whatsapp(FindItListing item) async {
    final number = item.whatsapp.replaceAll(RegExp(r'[^0-9]'), '');
    final message = Uri.encodeComponent('مرحبًا، وجدت ${item.itemName} عبر تطبيق خرائط اليمن. هل هو متوفر الآن؟');
    final uri = Uri.parse('https://wa.me/$number?text=$message');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  void _openMerchant() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => MerchantDashboardScreen(config: widget.config)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('وين ألاقيه؟'),
        actions: [
          IconButton(onPressed: _openMerchant, tooltip: 'إدارة نشاطي', icon: const Icon(Icons.storefront_rounded)),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: TextField(
              controller: _controller,
              autofocus: true,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _search(),
              decoration: InputDecoration(
                hintText: 'ما الذي تبحث عنه؟ منتج، دواء، فني، خدمة...',
                prefixIcon: const Icon(Icons.manage_search_rounded),
                suffixIcon: IconButton(onPressed: _search, icon: const Icon(Icons.search_rounded)),
              ),
            ),
          ),
          SizedBox(
            height: 42,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              scrollDirection: Axis.horizontal,
              itemCount: _examples.length,
              separatorBuilder: (_, __) => const SizedBox(width: 7),
              itemBuilder: (_, index) => ActionChip(label: Text(_examples[index]), onPressed: () => _search(_examples[index])),
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 42,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: FindItSort.values.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 7),
                      itemBuilder: (_, index) {
                        final sort = FindItSort.values[index];
                        return ChoiceChip(label: Text(sort.label), selected: _sort == sort, onSelected: (_) => _changeSort(sort));
                      },
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Badge(
                  isLabelVisible: _filters.isCustomized,
                  child: IconButton.filledTonal(onPressed: _openFilters, tooltip: 'الفلاتر', icon: const Icon(Icons.tune_rounded)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const Text('وسيلة التنقل:', style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(width: 8),
                Expanded(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: TransportMode.values.map((mode) => Padding(
                        padding: const EdgeInsets.only(left: 6),
                        child: ChoiceChip(
                          avatar: Icon(mode.icon, size: 17),
                          label: Text(mode.label),
                          selected: _mode == mode,
                          onSelected: (_) => setState(() => _mode = mode),
                        ),
                      )).toList(),
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (_loading) const LinearProgressIndicator(minHeight: 2),
          if (_demo && _items.isNotEmpty)
            Container(
              margin: const EdgeInsets.fromLTRB(16, 7, 16, 0),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              decoration: BoxDecoration(color: const Color(0xFFFFF6D8), borderRadius: BorderRadius.circular(14)),
              child: const Row(children: [
                Icon(Icons.science_outlined, size: 19, color: Color(0xFF8D6500)),
                SizedBox(width: 7),
                Expanded(child: Text('هذه نتائج تجريبية محلية حتى يتم ربط قاعدة بيانات التجار بالسيرفر.', style: TextStyle(fontSize: 12.5))),
              ]),
            ),
          if (_error != null) Padding(padding: const EdgeInsets.all(12), child: Text(_error!, style: const TextStyle(color: Colors.red))),
          Expanded(
            child: _items.isEmpty && !_loading
                ? _EmptyFindIt(hasQuery: _lastQuery.isNotEmpty, onMerchant: _openMerchant)
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(12, 10, 12, 24),
                    itemCount: _items.length,
                    itemBuilder: (_, index) {
                      final item = _items[index];
                      return FindItResultCard(
                        item: item,
                        onCall: () => _call(item.phone),
                        onWhatsapp: () => _whatsapp(item),
                        onMap: () => _showOnMap(item),
                        onNavigate: () => _navigate(item),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _EmptyFindIt extends StatelessWidget {
  const _EmptyFindIt({required this.hasQuery, required this.onMerchant});
  final bool hasQuery;
  final VoidCallback onMerchant;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 88,
              height: 88,
              decoration: const BoxDecoration(color: Color(0xFFE8F3FF), shape: BoxShape.circle),
              child: const Icon(Icons.search_rounded, size: 48, color: Color(0xFF1478F5)),
            ),
            const SizedBox(height: 14),
            Text(hasQuery ? 'لم نجد نتيجة مطابقة' : 'ابحث عن الشيء نفسه، وليس اسم المحل', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900), textAlign: TextAlign.center),
            const SizedBox(height: 7),
            Text(
              hasQuery ? 'جرّب اسمًا أقصر أو عدّل المنطقة والمسافة والفلاتر.' : 'مثال: بطارية طاقة شمسية، شاشة جوال، دواء، سباك أو كهربائي.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            OutlinedButton.icon(onPressed: onMerchant, icon: const Icon(Icons.storefront_rounded), label: const Text('أنا تاجر أو مقدم خدمة')),
          ],
        ),
      ),
    );
  }
}
