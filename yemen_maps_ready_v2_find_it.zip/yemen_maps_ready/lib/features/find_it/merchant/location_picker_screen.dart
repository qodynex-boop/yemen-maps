import 'package:flutter/material.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import '../../../core/config/app_config.dart';

class LocationPickerScreen extends StatefulWidget {
  const LocationPickerScreen({
    super.key,
    required this.config,
    this.initialPosition,
  });

  final AppConfig config;
  final LatLng? initialPosition;

  @override
  State<LocationPickerScreen> createState() => _LocationPickerScreenState();
}

class _LocationPickerScreenState extends State<LocationPickerScreen> {
  MapLibreMapController? _controller;
  late LatLng _selected;

  @override
  void initState() {
    super.initState();
    _selected = widget.initialPosition ?? LatLng(widget.config.defaultLatitude, widget.config.defaultLongitude);
  }

  Future<void> _drawSelected() async {
    final controller = _controller;
    if (controller == null) return;
    if (controller.circles.isNotEmpty) {
      await controller.removeCircles(controller.circles.toList());
    }
    await controller.addCircle(CircleOptions(
      geometry: _selected,
      circleColor: '#E53935',
      circleRadius: 8,
      circleStrokeColor: '#FFFFFF',
      circleStrokeWidth: 3,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حدد موقع النشاط')),
      body: Stack(
        children: [
          MapLibreMap(
            styleString: widget.config.mapStyleUrl,
            initialCameraPosition: CameraPosition(target: _selected, zoom: 15),
            onMapCreated: (controller) => _controller = controller,
            onStyleLoadedCallback: _drawSelected,
            onMapClick: (_, point) {
              setState(() => _selected = point);
              _drawSelected();
            },
            myLocationEnabled: true,
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 20,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${_selected.latitude.toStringAsFixed(6)}, ${_selected.longitude.toStringAsFixed(6)}',
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: () => Navigator.pop(context, _selected),
                        icon: const Icon(Icons.check_rounded),
                        label: const Text('اعتماد هذا الموقع'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
