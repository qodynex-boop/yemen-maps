import 'package:flutter/material.dart';
import '../../../core/config/app_config.dart';
import '../models/find_it_listing.dart';
import 'merchant_item_form_screen.dart';
import 'merchant_local_repository.dart';
import 'merchant_models.dart';
import 'merchant_store_form_screen.dart';

class MerchantDashboardScreen extends StatefulWidget {
  const MerchantDashboardScreen({super.key, required this.config});
  final AppConfig config;

  @override
  State<MerchantDashboardScreen> createState() => _MerchantDashboardScreenState();
}

class _MerchantDashboardScreenState extends State<MerchantDashboardScreen> {
  final _repo = MerchantLocalRepository();
  MerchantStoreDraft? _store;
  List<MerchantItemDraft> _items = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final store = await _repo.loadStore();
    final items = await _repo.loadItems();
    if (!mounted) return;
    setState(() {
      _store = store;
      _items = items..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
      _loading = false;
    });
  }

  Future<void> _editStore() async {
    final result = await Navigator.push<MerchantStoreDraft>(
      context,
      MaterialPageRoute(builder: (_) => MerchantStoreFormScreen(config: widget.config, initial: _store)),
    );
    if (result != null) await _load();
  }

  Future<void> _editItem([MerchantItemDraft? item]) async {
    if (_store == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أضف بيانات متجرك أو خدمتك أولًا.')));
      await _editStore();
      return;
    }
    final result = await Navigator.push<MerchantItemDraft>(
      context,
      MaterialPageRoute(builder: (_) => MerchantItemFormScreen(initial: item)),
    );
    if (result != null) await _load();
  }

  Future<void> _delete(MerchantItemDraft item) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('حذف العنصر؟'),
        content: Text('سيتم حذف «${item.name}» من المسودة المحلية.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
        ],
      ),
    );
    if (yes == true) {
      await _repo.deleteItem(item.id);
      await _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة نشاطي')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editItem(),
        icon: const Icon(Icons.add_rounded),
        label: const Text('إضافة منتج أو خدمة'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF7DB),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.cloud_off_rounded, color: Color(0xFF9B6900)),
                      SizedBox(width: 10),
                      Expanded(child: Text('وضع تجهيز محلي: البيانات محفوظة على الجهاز الآن. بنية السيرفر وواجهات API مهيأة لربطها لاحقًا بدون تغيير الشاشة.')),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                _store == null ? _emptyStore() : _storeCard(_store!),
                const SizedBox(height: 22),
                Row(
                  children: [
                    const Expanded(child: Text('المنتجات والخدمات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
                    Text('${_items.length} عنصر', style: const TextStyle(color: Color(0xFF7A8498))),
                  ],
                ),
                const SizedBox(height: 10),
                if (_items.isEmpty)
                  Container(
                    padding: const EdgeInsets.all(28),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
                    child: const Column(
                      children: [
                        Icon(Icons.inventory_2_outlined, size: 56, color: Color(0xFF1478F5)),
                        SizedBox(height: 10),
                        Text('لا توجد منتجات أو خدمات بعد', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                        SizedBox(height: 5),
                        Text('أضف ما تبيعه أو تقدمه ليظهر لاحقًا في نتائج «وين ألاقيه؟».', textAlign: TextAlign.center),
                      ],
                    ),
                  )
                else
                  ..._items.map(_itemCard),
              ],
            ),
    );
  }

  Widget _emptyStore() => Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
        child: Column(
          children: [
            const Icon(Icons.storefront_rounded, size: 62, color: Color(0xFF1478F5)),
            const SizedBox(height: 10),
            const Text('أضف متجرك أو خدمتك', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            const Text('حدد الاسم، أرقام التواصل، الموقع على الخريطة وأوقات العمل.', textAlign: TextAlign.center),
            const SizedBox(height: 14),
            FilledButton.icon(onPressed: _editStore, icon: const Icon(Icons.add_location_alt_rounded), label: const Text('إضافة النشاط')),
          ],
        ),
      );

  Widget _storeCard(MerchantStoreDraft s) => Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(color: const Color(0xFFE8F3FF), borderRadius: BorderRadius.circular(17)),
                child: const Icon(Icons.storefront_rounded, color: Color(0xFF1478F5)),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(s.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
                Text('${s.governorate} • ${s.district}'),
              ])),
              IconButton(onPressed: _editStore, icon: const Icon(Icons.edit_rounded)),
            ]),
            const Divider(height: 26),
            Text(s.address),
            const SizedBox(height: 5),
            Text('العمل: ${s.openingHours}'),
            const SizedBox(height: 5),
            Text('هاتف: ${s.phone}  •  واتساب: ${s.whatsapp}'),
            const SizedBox(height: 5),
            Text('الإحداثيات: ${s.position.latitude.toStringAsFixed(5)}, ${s.position.longitude.toStringAsFixed(5)}'),
          ],
        ),
      );

  Widget _itemCard(MerchantItemDraft i) {
    final availableColor = switch (i.availability) {
      AvailabilityStatus.available => const Color(0xFF0B9E65),
      AvailabilityStatus.unavailable => const Color(0xFFD63D3D),
      AvailabilityStatus.onRequest => const Color(0xFFB27900),
    };
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: const Color(0xFFF0F5FF),
              child: Icon(i.type == ListingType.product ? Icons.inventory_2_rounded : Icons.handyman_rounded, color: const Color(0xFF1478F5)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(i.name, style: const TextStyle(fontWeight: FontWeight.w900)),
                  Text('${i.type.label} • ${i.category}'),
                  const SizedBox(height: 4),
                  Wrap(spacing: 8, children: [
                    Text(i.availability.label, style: TextStyle(color: availableColor, fontWeight: FontWeight.w800)),
                    if (i.price != null) Text('${i.price!.toStringAsFixed(0)} ${i.currency}', style: const TextStyle(fontWeight: FontWeight.w800)),
                  ]),
                ],
              ),
            ),
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'edit') _editItem(i);
                if (value == 'delete') _delete(i);
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'edit', child: Text('تعديل')),
                PopupMenuItem(value: 'delete', child: Text('حذف')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
