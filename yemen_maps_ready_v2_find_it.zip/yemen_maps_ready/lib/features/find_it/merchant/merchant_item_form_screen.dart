import 'package:flutter/material.dart';
import '../models/find_it_listing.dart';
import 'merchant_local_repository.dart';
import 'merchant_models.dart';

class MerchantItemFormScreen extends StatefulWidget {
  const MerchantItemFormScreen({super.key, this.initial});
  final MerchantItemDraft? initial;

  @override
  State<MerchantItemFormScreen> createState() => _MerchantItemFormScreenState();
}

class _MerchantItemFormScreenState extends State<MerchantItemFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _repo = MerchantLocalRepository();
  late final TextEditingController _name;
  late final TextEditingController _category;
  late final TextEditingController _price;
  late final TextEditingController _description;
  late ListingType _type;
  late AvailabilityStatus _availability;
  late String _currency;

  @override
  void initState() {
    super.initState();
    final i = widget.initial;
    _name = TextEditingController(text: i?.name ?? '');
    _category = TextEditingController(text: i?.category ?? '');
    _price = TextEditingController(text: i?.price?.toStringAsFixed(0) ?? '');
    _description = TextEditingController(text: i?.description ?? '');
    _type = i?.type ?? ListingType.product;
    _availability = i?.availability ?? AvailabilityStatus.available;
    _currency = i?.currency ?? 'YER';
  }

  @override
  void dispose() {
    _name.dispose();
    _category.dispose();
    _price.dispose();
    _description.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final item = MerchantItemDraft(
      id: widget.initial?.id ?? 'local-item-${DateTime.now().millisecondsSinceEpoch}',
      name: _name.text.trim(),
      type: _type,
      category: _category.text.trim(),
      price: _price.text.trim().isEmpty ? null : double.tryParse(_price.text.trim()),
      currency: _currency,
      availability: _availability,
      description: _description.text.trim().isEmpty ? null : _description.text.trim(),
      updatedAt: DateTime.now(),
    );
    await _repo.saveItem(item);
    if (mounted) Navigator.pop(context, item);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.initial == null ? 'إضافة منتج أو خدمة' : 'تعديل المنتج أو الخدمة')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            SegmentedButton<ListingType>(
              segments: const [
                ButtonSegment(value: ListingType.product, label: Text('منتج'), icon: Icon(Icons.inventory_2_outlined)),
                ButtonSegment(value: ListingType.service, label: Text('خدمة'), icon: Icon(Icons.handyman_outlined)),
              ],
              selected: {_type},
              onSelectionChanged: (v) => setState(() => _type = v.first),
            ),
            const SizedBox(height: 14),
            TextFormField(controller: _name, validator: _required, decoration: const InputDecoration(labelText: 'اسم المنتج أو الخدمة')),
            const SizedBox(height: 12),
            TextFormField(controller: _category, validator: _required, decoration: const InputDecoration(labelText: 'التصنيف — مثال: طاقة شمسية')),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: TextFormField(controller: _price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعر — اختياري'))),
              const SizedBox(width: 10),
              SizedBox(
                width: 105,
                child: DropdownButtonFormField<String>(
                  initialValue: _currency,
                  decoration: const InputDecoration(labelText: 'العملة'),
                  items: const ['YER', 'SAR', 'USD'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                  onChanged: (v) => setState(() => _currency = v ?? 'YER'),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            DropdownButtonFormField<AvailabilityStatus>(
              initialValue: _availability,
              decoration: const InputDecoration(labelText: 'حالة التوفر'),
              items: AvailabilityStatus.values.map((e) => DropdownMenuItem(value: e, child: Text(e.label))).toList(),
              onChanged: (v) => setState(() => _availability = v ?? AvailabilityStatus.available),
            ),
            const SizedBox(height: 12),
            TextFormField(controller: _description, maxLines: 3, decoration: const InputDecoration(labelText: 'وصف مختصر')),
            const SizedBox(height: 20),
            FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_rounded), label: const Text('حفظ')),
          ],
        ),
      ),
    );
  }

  String? _required(String? value) => value == null || value.trim().isEmpty ? 'هذا الحقل مطلوب' : null;
}
