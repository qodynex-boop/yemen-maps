import 'package:flutter/material.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import '../../../core/config/app_config.dart';
import 'location_picker_screen.dart';
import 'merchant_local_repository.dart';
import 'merchant_models.dart';

class MerchantStoreFormScreen extends StatefulWidget {
  const MerchantStoreFormScreen({super.key, required this.config, this.initial});
  final AppConfig config;
  final MerchantStoreDraft? initial;

  @override
  State<MerchantStoreFormScreen> createState() => _MerchantStoreFormScreenState();
}

class _MerchantStoreFormScreenState extends State<MerchantStoreFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _repo = MerchantLocalRepository();
  late final TextEditingController _name;
  late final TextEditingController _phone;
  late final TextEditingController _whatsapp;
  late final TextEditingController _governorate;
  late final TextEditingController _district;
  late final TextEditingController _address;
  late final TextEditingController _hours;
  LatLng? _position;

  @override
  void initState() {
    super.initState();
    final s = widget.initial;
    _name = TextEditingController(text: s?.name ?? '');
    _phone = TextEditingController(text: s?.phone ?? '');
    _whatsapp = TextEditingController(text: s?.whatsapp ?? '');
    _governorate = TextEditingController(text: s?.governorate ?? 'صنعاء');
    _district = TextEditingController(text: s?.district ?? '');
    _address = TextEditingController(text: s?.address ?? '');
    _hours = TextEditingController(text: s?.openingHours ?? '08:00 - 20:00');
    _position = s?.position;
  }

  @override
  void dispose() {
    for (final c in [_name, _phone, _whatsapp, _governorate, _district, _address, _hours]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickLocation() async {
    final result = await Navigator.push<LatLng>(
      context,
      MaterialPageRoute(builder: (_) => LocationPickerScreen(config: widget.config, initialPosition: _position)),
    );
    if (result != null) setState(() => _position = result);
  }

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    if (_position == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('حدد موقع النشاط على الخريطة أولًا.')));
      return;
    }
    final draft = MerchantStoreDraft(
      id: widget.initial?.id ?? 'local-${DateTime.now().millisecondsSinceEpoch}',
      name: _name.text.trim(),
      phone: _phone.text.trim(),
      whatsapp: _whatsapp.text.trim(),
      governorate: _governorate.text.trim(),
      district: _district.text.trim(),
      address: _address.text.trim(),
      position: _position!,
      openingHours: _hours.text.trim(),
    );
    await _repo.saveStore(draft);
    if (mounted) Navigator.pop(context, draft);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.initial == null ? 'إضافة متجر أو مقدم خدمة' : 'تعديل بيانات النشاط')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _field(_name, 'اسم المتجر أو مقدم الخدمة', required: true),
            _field(_phone, 'رقم الهاتف', required: true, keyboardType: TextInputType.phone),
            _field(_whatsapp, 'رقم واتساب', required: true, keyboardType: TextInputType.phone),
            Row(children: [
              Expanded(child: _field(_governorate, 'المحافظة', required: true)),
              const SizedBox(width: 10),
              Expanded(child: _field(_district, 'المنطقة / الحي', required: true)),
            ]),
            _field(_address, 'العنوان الوصفي', required: true, maxLines: 2),
            _field(_hours, 'أوقات العمل', required: true),
            const SizedBox(height: 4),
            OutlinedButton.icon(
              onPressed: _pickLocation,
              icon: const Icon(Icons.location_on_rounded),
              label: Text(_position == null ? 'حدد الموقع على الخريطة' : 'الموقع محدد — اضغط للتعديل'),
            ),
            if (_position != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text('${_position!.latitude.toStringAsFixed(6)}, ${_position!.longitude.toStringAsFixed(6)}', textAlign: TextAlign.center),
              ),
            const SizedBox(height: 20),
            FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_rounded), label: const Text('حفظ البيانات')),
            const SizedBox(height: 12),
            const Text('يتم حفظ هذه البيانات محليًا الآن. عند ربط السيرفر ستُرسل لنفس بنية API دون تغيير الواجهة.', textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label, {bool required = false, TextInputType? keyboardType, int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: c,
        keyboardType: keyboardType,
        maxLines: maxLines,
        validator: required ? (v) => (v == null || v.trim().isEmpty) ? 'هذا الحقل مطلوب' : null : null,
        decoration: InputDecoration(labelText: label),
      ),
    );
  }
}
