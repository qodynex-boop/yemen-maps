import 'package:maplibre_gl/maplibre_gl.dart';
import '../models/find_it_listing.dart';

class MerchantStoreDraft {
  const MerchantStoreDraft({
    required this.id,
    required this.name,
    required this.phone,
    required this.whatsapp,
    required this.governorate,
    required this.district,
    required this.address,
    required this.position,
    required this.openingHours,
  });

  final String id;
  final String name;
  final String phone;
  final String whatsapp;
  final String governorate;
  final String district;
  final String address;
  final LatLng position;
  final String openingHours;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'phone': phone,
        'whatsapp': whatsapp,
        'governorate': governorate,
        'district': district,
        'address': address,
        'latitude': position.latitude,
        'longitude': position.longitude,
        'openingHours': openingHours,
      };

  factory MerchantStoreDraft.fromJson(Map<String, dynamic> json) => MerchantStoreDraft(
        id: json['id'].toString(),
        name: (json['name'] ?? '').toString(),
        phone: (json['phone'] ?? '').toString(),
        whatsapp: (json['whatsapp'] ?? '').toString(),
        governorate: (json['governorate'] ?? 'صنعاء').toString(),
        district: (json['district'] ?? '').toString(),
        address: (json['address'] ?? '').toString(),
        position: LatLng(
          (json['latitude'] as num).toDouble(),
          (json['longitude'] as num).toDouble(),
        ),
        openingHours: (json['openingHours'] ?? '').toString(),
      );
}

class MerchantItemDraft {
  const MerchantItemDraft({
    required this.id,
    required this.name,
    required this.type,
    required this.category,
    required this.currency,
    required this.availability,
    required this.updatedAt,
    this.price,
    this.description,
  });

  final String id;
  final String name;
  final ListingType type;
  final String category;
  final double? price;
  final String currency;
  final AvailabilityStatus availability;
  final String? description;
  final DateTime updatedAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'type': type.apiValue,
        'category': category,
        'price': price,
        'currency': currency,
        'availability': availability.apiValue,
        'description': description,
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory MerchantItemDraft.fromJson(Map<String, dynamic> json) => MerchantItemDraft(
        id: json['id'].toString(),
        name: (json['name'] ?? '').toString(),
        type: ListingTypeX.fromApi(json['type']?.toString()),
        category: (json['category'] ?? '').toString(),
        price: (json['price'] as num?)?.toDouble(),
        currency: (json['currency'] ?? 'YER').toString(),
        availability: AvailabilityStatusX.fromApi(json['availability']?.toString()),
        description: json['description']?.toString(),
        updatedAt: DateTime.tryParse((json['updatedAt'] ?? '').toString()) ?? DateTime.now(),
      );
}
