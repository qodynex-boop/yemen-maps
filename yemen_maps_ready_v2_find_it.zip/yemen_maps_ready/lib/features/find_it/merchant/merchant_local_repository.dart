import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'merchant_models.dart';

class MerchantLocalRepository {
  static const _storeKey = 'find_it_merchant_store_draft_v1';
  static const _itemsKey = 'find_it_merchant_items_draft_v1';

  Future<MerchantStoreDraft?> loadStore() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storeKey);
    if (raw == null || raw.isEmpty) return null;
    return MerchantStoreDraft.fromJson(Map<String, dynamic>.from(jsonDecode(raw) as Map));
  }

  Future<void> saveStore(MerchantStoreDraft store) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_storeKey, jsonEncode(store.toJson()));
  }

  Future<List<MerchantItemDraft>> loadItems() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_itemsKey);
    if (raw == null || raw.isEmpty) return [];
    final decoded = jsonDecode(raw) as List<dynamic>;
    return decoded.map((e) => MerchantItemDraft.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<void> saveItem(MerchantItemDraft item) async {
    final items = await loadItems();
    final index = items.indexWhere((e) => e.id == item.id);
    if (index >= 0) {
      items[index] = item;
    } else {
      items.add(item);
    }
    await _saveItems(items);
  }

  Future<void> deleteItem(String id) async {
    final items = await loadItems();
    items.removeWhere((e) => e.id == id);
    await _saveItems(items);
  }

  Future<void> _saveItems(List<MerchantItemDraft> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_itemsKey, jsonEncode(items.map((e) => e.toJson()).toList()));
  }
}
