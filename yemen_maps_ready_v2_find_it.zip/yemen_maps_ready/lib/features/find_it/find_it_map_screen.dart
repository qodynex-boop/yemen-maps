import 'package:flutter/material.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import '../../core/config/app_config.dart';
import '../navigation/models/transport_mode.dart';
import '../navigation/navigation_screen.dart';
import 'models/find_it_listing.dart';

class FindItMapScreen extends StatefulWidget {
  const FindItMapScreen({
    super.key,
    required this.config,
    required this.listing,
    required this.mode,
  });

  final AppConfig config;
  final FindItListing listing;
  final TransportMode mode;

  @override
  State<FindItMapScreen> createState() => _FindItMapScreenState();
}

class _FindItMapScreenState extends State<FindItMapScreen> {
  MapLibreMapController? _controller;

  Future<void> _drawPin() async {
    final controller = _controller;
    if (controller == null) return;
    if (controller.circles.isNotEmpty) {
      await controller.removeCircles(controller.circles.toList());
    }
    await controller.addCircle(CircleOptions(
      geometry: widget.listing.position,
      circleColor: '#E53935',
      circleRadius: 9,
      circleStrokeColor: '#FFFFFF',
      circleStrokeWidth: 3,
    ));
  }

  void _navigate() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => NavigationScreen(
          config: widget.config,
          destination: widget.listing.position,
          destinationName: '${widget.listing.merchantName} - ${widget.listing.itemName}',
          initialMode: widget.mode,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('عرض على الخريطة')),
      body: Stack(
        children: [
          MapLibreMap(
            styleString: widget.config.mapStyleUrl,
            initialCameraPosition: CameraPosition(target: widget.listing.position, zoom: 16),
            myLocationEnabled: true,
            onMapCreated: (controller) => _controller = controller,
            onStyleLoadedCallback: _drawPin,
          ),
          Positioned(
            left: 14,
            right: 14,
            bottom: 18,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(widget.listing.itemName, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                    const SizedBox(height: 3),
                    Text('${widget.listing.merchantName} • ${widget.listing.district}'),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(onPressed: _navigate, icon: const Icon(Icons.navigation_rounded), label: const Text('اذهب للموقع')),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
