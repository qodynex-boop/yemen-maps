import 'package:maplibre_gl/maplibre_gl.dart';

enum ListingType { product, service }

enum AvailabilityStatus { available, unavailable, onRequest }

extension ListingTypeX on ListingType {
  String get apiValue => switch (this) {
        ListingType.product => 'product',
        ListingType.service => 'service',
      };

  String get label => switch (this) {
        ListingType.product => 'منتج',
        ListingType.service => 'خدمة',
      };

  static ListingType fromApi(String? value) => value == 'service' ? ListingType.service : ListingType.product;
}

extension AvailabilityStatusX on AvailabilityStatus {
  String get apiValue => switch (this) {
        AvailabilityStatus.available => 'available',
        AvailabilityStatus.unavailable => 'unavailable',
        AvailabilityStatus.onRequest => 'on_request',
      };

  String get label => switch (this) {
        AvailabilityStatus.available => 'متوفر',
        AvailabilityStatus.unavailable => 'غير متوفر',
        AvailabilityStatus.onRequest => 'حسب الطلب',
      };

  static AvailabilityStatus fromApi(String? value) => switch (value) {
        'unavailable' => AvailabilityStatus.unavailable,
        'on_request' => AvailabilityStatus.onRequest,
        _ => AvailabilityStatus.available,
      };
}

class FindItListing {
  const FindItListing({
    required this.id,
    required this.merchantId,
    required this.merchantName,
    required this.itemName,
    required this.type,
    required this.category,
    required this.availability,
    required this.governorate,
    required this.district,
    required this.position,
    required this.phone,
    required this.whatsapp,
    required this.updatedAt,
    this.price,
    this.currency = 'YER',
    this.address,
    this.openingHours,
    this.description,
    this.distanceMeters,
    this.searchAliases = const [],
    this.isDemo = false,
  });

  final String id;
  final String merchantId;
  final String merchantName;
  final String itemName;
  final ListingType type;
  final String category;
  final double? price;
  final String currency;
  final AvailabilityStatus availability;
  final String governorate;
  final String district;
  final String? address;
  final LatLng position;
  final String phone;
  final String whatsapp;
  final String? openingHours;
  final String? description;
  final DateTime updatedAt;
  final double? distanceMeters;
  final List<String> searchAliases;
  final bool isDemo;

  FindItListing copyWith({double? distanceMeters}) => FindItListing(
        id: id,
        merchantId: merchantId,
        merchantName: merchantName,
        itemName: itemName,
        type: type,
        category: category,
        price: price,
        currency: currency,
        availability: availability,
        governorate: governorate,
        district: district,
        address: address,
        position: position,
        phone: phone,
        whatsapp: whatsapp,
        openingHours: openingHours,
        description: description,
        updatedAt: updatedAt,
        distanceMeters: distanceMeters ?? this.distanceMeters,
        searchAliases: searchAliases,
        isDemo: isDemo,
      );

  factory FindItListing.fromJson(Map<String, dynamic> json) {
    return FindItListing(
      id: json['id'].toString(),
      merchantId: (json['merchantId'] ?? json['merchant_id'] ?? '').toString(),
      merchantName: (json['merchantName'] ?? json['merchant_name'] ?? 'متجر').toString(),
      itemName: (json['itemName'] ?? json['item_name'] ?? json['name'] ?? 'بدون اسم').toString(),
      type: ListingTypeX.fromApi((json['type'] ?? json['itemType'])?.toString()),
      category: (json['category'] ?? 'other').toString(),
      price: (json['price'] as num?)?.toDouble(),
      currency: (json['currency'] ?? 'YER').toString(),
      availability: AvailabilityStatusX.fromApi(json['availability']?.toString()),
      governorate: (json['governorate'] ?? 'صنعاء').toString(),
      district: (json['district'] ?? json['area'] ?? '').toString(),
      address: json['address']?.toString(),
      position: LatLng(
        (json['latitude'] as num).toDouble(),
        (json['longitude'] as num).toDouble(),
      ),
      phone: (json['phone'] ?? '').toString(),
      whatsapp: (json['whatsapp'] ?? json['phone'] ?? '').toString(),
      openingHours: json['openingHours']?.toString(),
      description: json['description']?.toString(),
      updatedAt: DateTime.tryParse((json['updatedAt'] ?? json['updated_at'] ?? '').toString()) ?? DateTime.now(),
      distanceMeters: (json['distanceMeters'] as num?)?.toDouble(),
      searchAliases: (json['searchAliases'] as List<dynamic>? ?? const []).map((e) => e.toString()).toList(),
      isDemo: json['isDemo'] == true,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'merchantId': merchantId,
        'merchantName': merchantName,
        'itemName': itemName,
        'type': type.apiValue,
        'category': category,
        'price': price,
        'currency': currency,
        'availability': availability.apiValue,
        'governorate': governorate,
        'district': district,
        'address': address,
        'latitude': position.latitude,
        'longitude': position.longitude,
        'phone': phone,
        'whatsapp': whatsapp,
        'openingHours': openingHours,
        'description': description,
        'updatedAt': updatedAt.toIso8601String(),
        'distanceMeters': distanceMeters,
        'searchAliases': searchAliases,
        'isDemo': isDemo,
      };
}
