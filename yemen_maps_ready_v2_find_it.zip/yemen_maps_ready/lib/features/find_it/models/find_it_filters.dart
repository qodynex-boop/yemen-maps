import 'find_it_listing.dart';

enum FindItSort { nearest, cheapest, latest, availableFirst }

extension FindItSortX on FindItSort {
  String get apiValue => switch (this) {
        FindItSort.nearest => 'nearest',
        FindItSort.cheapest => 'cheapest',
        FindItSort.latest => 'latest',
        FindItSort.availableFirst => 'available',
      };

  String get label => switch (this) {
        FindItSort.nearest => 'الأقرب',
        FindItSort.cheapest => 'الأرخص',
        FindItSort.latest => 'الأحدث تحديثًا',
        FindItSort.availableFirst => 'المتوفر حاليًا',
      };
}

class FindItFilters {
  const FindItFilters({
    this.governorate = 'صنعاء',
    this.district,
    this.type,
    this.minPrice,
    this.maxPrice,
    this.maxDistanceKm = 25,
    this.onlyAvailable = false,
  });

  final String governorate;
  final String? district;
  final ListingType? type;
  final double? minPrice;
  final double? maxPrice;
  final double maxDistanceKm;
  final bool onlyAvailable;

  bool get isCustomized =>
      (district?.trim().isNotEmpty ?? false) ||
      type != null ||
      minPrice != null ||
      maxPrice != null ||
      maxDistanceKm != 25 ||
      onlyAvailable;

  FindItFilters copyWith({
    String? governorate,
    String? district,
    bool clearDistrict = false,
    ListingType? type,
    bool clearType = false,
    double? minPrice,
    bool clearMinPrice = false,
    double? maxPrice,
    bool clearMaxPrice = false,
    double? maxDistanceKm,
    bool? onlyAvailable,
  }) {
    return FindItFilters(
      governorate: governorate ?? this.governorate,
      district: clearDistrict ? null : (district ?? this.district),
      type: clearType ? null : (type ?? this.type),
      minPrice: clearMinPrice ? null : (minPrice ?? this.minPrice),
      maxPrice: clearMaxPrice ? null : (maxPrice ?? this.maxPrice),
      maxDistanceKm: maxDistanceKm ?? this.maxDistanceKm,
      onlyAvailable: onlyAvailable ?? this.onlyAvailable,
    );
  }
}
