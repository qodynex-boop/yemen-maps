import 'package:flutter/material.dart';
import '../models/find_it_listing.dart';

class FindItResultCard extends StatelessWidget {
  const FindItResultCard({
    super.key,
    required this.item,
    required this.onCall,
    required this.onWhatsapp,
    required this.onMap,
    required this.onNavigate,
  });

  final FindItListing item;
  final VoidCallback onCall;
  final VoidCallback onWhatsapp;
  final VoidCallback onMap;
  final VoidCallback onNavigate;

  @override
  Widget build(BuildContext context) {
    final availabilityColor = switch (item.availability) {
      AvailabilityStatus.available => const Color(0xFF078B59),
      AvailabilityStatus.unavailable => const Color(0xFFD34444),
      AvailabilityStatus.onRequest => const Color(0xFFB87500),
    };
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(color: const Color(0xFFEAF3FF), borderRadius: BorderRadius.circular(16)),
                  child: Icon(item.type == ListingType.product ? Icons.inventory_2_rounded : Icons.handyman_rounded, color: const Color(0xFF1478F5)),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.itemName, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                      const SizedBox(height: 2),
                      Text(item.merchantName, style: const TextStyle(fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                  decoration: BoxDecoration(color: availabilityColor.withValues(alpha: .10), borderRadius: BorderRadius.circular(20)),
                  child: Text(item.availability.label, style: TextStyle(color: availabilityColor, fontWeight: FontWeight.w800, fontSize: 12)),
                ),
              ],
            ),
            const SizedBox(height: 13),
            Wrap(
              spacing: 12,
              runSpacing: 7,
              children: [
                if (item.price != null) _meta(Icons.payments_outlined, '${_formatPrice(item.price!)} ${item.currency}'),
                _meta(Icons.location_on_outlined, '${item.governorate} • ${item.district}'),
                if (item.distanceMeters != null) _meta(Icons.route_rounded, _distance(item.distanceMeters!)),
                _meta(Icons.update_rounded, 'آخر تحديث ${_relativeUpdate(item.updatedAt)}'),
              ],
            ),
            if (item.openingHours?.isNotEmpty == true) ...[
              const SizedBox(height: 8),
              _meta(Icons.schedule_rounded, item.openingHours!),
            ],
            const Divider(height: 24),
            Row(
              children: [
                Expanded(child: _action(context, Icons.call_rounded, 'اتصال', onCall)),
                const SizedBox(width: 6),
                Expanded(child: _action(context, Icons.chat_rounded, 'واتساب', onWhatsapp)),
                const SizedBox(width: 6),
                Expanded(child: _action(context, Icons.map_rounded, 'الخريطة', onMap)),
                const SizedBox(width: 6),
                Expanded(child: _action(context, Icons.navigation_rounded, 'اذهب', onNavigate, primary: true)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _meta(IconData icon, String text) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [Icon(icon, size: 16, color: const Color(0xFF7A8498)), const SizedBox(width: 4), Text(text, style: const TextStyle(fontSize: 12.5, color: Color(0xFF687386)))],
      );

  Widget _action(BuildContext context, IconData icon, String label, VoidCallback onTap, {bool primary = false}) {
    final color = primary ? Theme.of(context).colorScheme.primary : const Color(0xFF0A1D46);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 4),
        decoration: BoxDecoration(
          color: primary ? const Color(0xFFE7F1FF) : const Color(0xFFF5F7FA),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [Icon(icon, size: 20, color: color), const SizedBox(height: 3), Text(label, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: color))],
        ),
      ),
    );
  }

  String _formatPrice(double value) {
    final raw = value.toStringAsFixed(value % 1 == 0 ? 0 : 2);
    return raw.replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (match) => ',');
  }

  String _distance(double meters) => meters < 1000 ? '${meters.round()} م' : '${(meters / 1000).toStringAsFixed(1)} كم';

  String _relativeUpdate(DateTime value) {
    final diff = DateTime.now().difference(value.toLocal());
    if (diff.isNegative) return 'الآن';
    if (diff.inMinutes < 60) return 'منذ ${diff.inMinutes.clamp(1, 59)} د';
    if (diff.inHours < 24) return 'منذ ${diff.inHours} س';
    if (diff.inDays < 30) return 'منذ ${diff.inDays} يوم';
    return '${value.year}/${value.month.toString().padLeft(2, '0')}/${value.day.toString().padLeft(2, '0')}';
  }
}
