import 'package:flutter/material.dart';
import '../models/find_it_filters.dart';
import '../models/find_it_listing.dart';

class FindItFiltersSheet extends StatefulWidget {
  const FindItFiltersSheet({super.key, required this.initial});
  final FindItFilters initial;

  @override
  State<FindItFiltersSheet> createState() => _FindItFiltersSheetState();
}

class _FindItFiltersSheetState extends State<FindItFiltersSheet> {
  late final TextEditingController _governorate;
  late final TextEditingController _district;
  late final TextEditingController _minPrice;
  late final TextEditingController _maxPrice;
  ListingType? _type;
  late double _distance;
  late bool _onlyAvailable;

  @override
  void initState() {
    super.initState();
    _governorate = TextEditingController(text: widget.initial.governorate);
    _district = TextEditingController(text: widget.initial.district ?? '');
    _minPrice = TextEditingController(text: widget.initial.minPrice?.toStringAsFixed(0) ?? '');
    _maxPrice = TextEditingController(text: widget.initial.maxPrice?.toStringAsFixed(0) ?? '');
    _type = widget.initial.type;
    _distance = widget.initial.maxDistanceKm;
    _onlyAvailable = widget.initial.onlyAvailable;
  }

  @override
  void dispose() {
    _governorate.dispose();
    _district.dispose();
    _minPrice.dispose();
    _maxPrice.dispose();
    super.dispose();
  }

  void _apply() {
    Navigator.pop(
      context,
      FindItFilters(
        governorate: _governorate.text.trim().isEmpty ? 'صنعاء' : _governorate.text.trim(),
        district: _district.text.trim().isEmpty ? null : _district.text.trim(),
        type: _type,
        minPrice: double.tryParse(_minPrice.text.trim()),
        maxPrice: double.tryParse(_maxPrice.text.trim()),
        maxDistanceKm: _distance,
        onlyAvailable: _onlyAvailable,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(18, 14, 18, 18 + MediaQuery.viewInsetsOf(context).bottom),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(child: Container(width: 45, height: 5, decoration: BoxDecoration(color: const Color(0xFFD6DBE5), borderRadius: BorderRadius.circular(99)))),
            const SizedBox(height: 14),
            const Text('تصفية النتائج', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: TextField(controller: _governorate, decoration: const InputDecoration(labelText: 'المحافظة'))),
              const SizedBox(width: 10),
              Expanded(child: TextField(controller: _district, decoration: const InputDecoration(labelText: 'المنطقة / الحي'))),
            ]),
            const SizedBox(height: 14),
            const Text('النوع', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 7),
            Wrap(
              spacing: 8,
              children: [
                ChoiceChip(label: const Text('الكل'), selected: _type == null, onSelected: (_) => setState(() => _type = null)),
                ChoiceChip(label: const Text('منتج'), selected: _type == ListingType.product, onSelected: (_) => setState(() => _type = ListingType.product)),
                ChoiceChip(label: const Text('خدمة'), selected: _type == ListingType.service, onSelected: (_) => setState(() => _type = ListingType.service)),
              ],
            ),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: TextField(controller: _minPrice, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'أقل سعر'))),
              const SizedBox(width: 10),
              Expanded(child: TextField(controller: _maxPrice, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'أعلى سعر'))),
            ]),
            const SizedBox(height: 16),
            Row(children: [
              const Expanded(child: Text('أقصى مسافة', style: TextStyle(fontWeight: FontWeight.w800))),
              Text('${_distance.toStringAsFixed(0)} كم', style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF1478F5))),
            ]),
            Slider(value: _distance, min: 1, max: 100, divisions: 99, label: '${_distance.toStringAsFixed(0)} كم', onChanged: (v) => setState(() => _distance = v)),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('المتوفر فقط', style: TextStyle(fontWeight: FontWeight.w800)),
              value: _onlyAvailable,
              onChanged: (v) => setState(() => _onlyAvailable = v),
            ),
            const SizedBox(height: 8),
            FilledButton.icon(onPressed: _apply, icon: const Icon(Icons.tune_rounded), label: const Text('تطبيق الفلاتر')),
            TextButton(
              onPressed: () => Navigator.pop(context, const FindItFilters()),
              child: const Text('إعادة تعيين'),
            ),
          ],
        ),
      ),
    );
  }
}
